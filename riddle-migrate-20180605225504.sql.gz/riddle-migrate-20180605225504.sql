# WordPress MySQL database migration
#
# Generated: Tuesday 5. June 2018 22:55 UTC
# Hostname: localhost
# Database: `riddle`
# URL: //riddle-demo.com
# Path: /Applications/MAMP/htdocs/riddle
# Tables: wp_commentmeta, wp_comments, wp_gf_draft_submissions, wp_gf_entry, wp_gf_entry_meta, wp_gf_entry_notes, wp_gf_form, wp_gf_form_meta, wp_gf_form_view, wp_itsec_distributed_storage, wp_itsec_lockouts, wp_itsec_logs, wp_itsec_temp, wp_links, wp_options, wp_postmeta, wp_posts, wp_simple_history, wp_simple_history_contexts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_seo_links, wp_yoast_seo_meta
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-05-24 15:18:28', '2018-05-24 15:18:28', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_draft_submissions`
#

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;


#
# Table structure of table `wp_gf_draft_submissions`
#

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_draft_submissions`
#

#
# End of data contents of table `wp_gf_draft_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry`
#

DROP TABLE IF EXISTS `wp_gf_entry`;


#
# Table structure of table `wp_gf_entry`
#

CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry`
#

#
# End of data contents of table `wp_gf_entry`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_meta`
#

DROP TABLE IF EXISTS `wp_gf_entry_meta`;


#
# Table structure of table `wp_gf_entry_meta`
#

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_meta`
#

#
# End of data contents of table `wp_gf_entry_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_notes`
#

DROP TABLE IF EXISTS `wp_gf_entry_notes`;


#
# Table structure of table `wp_gf_entry_notes`
#

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_notes`
#

#
# End of data contents of table `wp_gf_entry_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form`
#

DROP TABLE IF EXISTS `wp_gf_form`;


#
# Table structure of table `wp_gf_form`
#

CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form`
#
INSERT INTO `wp_gf_form` ( `id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Free Consultation', '2018-05-31 18:05:14', NULL, 1, 0),
(2, 'Free Consultation Sidebar', '2018-06-01 22:08:48', NULL, 1, 0) ;

#
# End of data contents of table `wp_gf_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_meta`
#

DROP TABLE IF EXISTS `wp_gf_form_meta`;


#
# Table structure of table `wp_gf_form_meta`
#

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_meta`
#
INSERT INTO `wp_gf_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Free Consultation","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit Your Message Now","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"email","id":5,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"textarea","id":4,"label":"Please Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Please Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false}],"version":"2.3.1","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5b10395ad5842":{"id":"5b10395ad5842","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5b10395ad7572":{"id":"5b10395ad7572","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":false,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5b10395ad7572":{"id":"5b10395ad7572","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":43,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5b10395ad5842":{"id":"5b10395ad5842","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(2, '{"title":"Free Consultation Sidebar","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit Your Message Now","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"email","id":5,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false},{"type":"textarea","id":4,"label":"Please Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Please Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"pageNumber":1,"displayOnly":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false}],"version":"2.3.1","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":false,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"5b10395ad5842":{"id":"5b10395ad5842","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5b10395ad7572":{"id":"5b10395ad7572","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":43,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}}', NULL, '{"5b10395ad7572":{"id":"5b10395ad7572","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":43,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5b10395ad5842":{"id":"5b10395ad5842","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_gf_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_view`
#

DROP TABLE IF EXISTS `wp_gf_form_view`;


#
# Table structure of table `wp_gf_form_view`
#

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_view`
#
INSERT INTO `wp_gf_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2018-05-31 18:06:16', '', 132),
(2, 1, '2018-06-01 19:13:06', '', 161),
(3, 2, '2018-06-01 22:09:39', '', 3),
(4, 2, '2018-06-04 15:21:48', '', 171),
(5, 1, '2018-06-04 15:21:48', '', 176),
(6, 2, '2018-06-05 15:31:45', '', 68),
(7, 1, '2018-06-05 15:31:45', '', 154) ;

#
# End of data contents of table `wp_gf_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_distributed_storage`
#

DROP TABLE IF EXISTS `wp_itsec_distributed_storage`;


#
# Table structure of table `wp_itsec_distributed_storage`
#

CREATE TABLE `wp_itsec_distributed_storage` (
  `storage_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `storage_group` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_key` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `storage_chunk` int(11) NOT NULL DEFAULT '0',
  `storage_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_updated` datetime NOT NULL,
  PRIMARY KEY (`storage_id`),
  UNIQUE KEY `storage_group__key__chunk` (`storage_group`,`storage_key`,`storage_chunk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_distributed_storage`
#

#
# End of data contents of table `wp_itsec_distributed_storage`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_lockouts`
#

DROP TABLE IF EXISTS `wp_itsec_lockouts`;


#
# Table structure of table `wp_itsec_lockouts`
#

CREATE TABLE `wp_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_lockouts`
#

#
# End of data contents of table `wp_itsec_lockouts`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_logs`
#

DROP TABLE IF EXISTS `wp_itsec_logs`;


#
# Table structure of table `wp_itsec_logs`
#

CREATE TABLE `wp_itsec_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `code` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'notice',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `init_timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `memory_current` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memory_peak` bigint(20) unsigned NOT NULL DEFAULT '0',
  `url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `remote_ip` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `code` (`code`),
  KEY `type` (`type`),
  KEY `timestamp` (`timestamp`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_logs`
#
INSERT INTO `wp_itsec_logs` ( `id`, `parent_id`, `module`, `code`, `data`, `type`, `timestamp`, `init_timestamp`, `memory_current`, `memory_peak`, `url`, `blog_id`, `user_id`, `remote_ip`) VALUES
(1, 0, 'brute_force', 'invalid-login', 'a:5:{s:7:"details";a:2:{s:6:"source";s:12:"wp-login.php";s:20:"authentication_types";a:1:{i:0;s:21:"username_and_password";}}s:4:"user";O:8:"WP_Error":2:{s:6:"errors";a:1:{s:18:"incorrect_password";a:1:{i:0;s:197:"<strong>ERROR</strong>: The password you entered for the username <strong>1p21.admin</strong> is incorrect. <a href="http://riddle-demo.com/wp-login.php?action=lostpassword">Lost your password?</a>";}}s:10:"error_data";a:0:{}}s:8:"username";s:10:"1p21.admin";s:7:"user_id";i:1;s:6:"SERVER";a:35:{s:15:"SERVER_SOFTWARE";s:6:"Apache";s:11:"REQUEST_URI";s:13:"/wp-login.php";s:9:"HTTP_HOST";s:15:"riddle-demo.com";s:15:"HTTP_CONNECTION";s:10:"keep-alive";s:14:"CONTENT_LENGTH";s:2:"81";s:18:"HTTP_CACHE_CONTROL";s:9:"max-age=0";s:11:"HTTP_ORIGIN";s:22:"http://riddle-demo.com";s:30:"HTTP_UPGRADE_INSECURE_REQUESTS";s:1:"1";s:12:"CONTENT_TYPE";s:33:"application/x-www-form-urlencoded";s:15:"HTTP_USER_AGENT";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36";s:11:"HTTP_ACCEPT";s:85:"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";s:12:"HTTP_REFERER";s:65:"http://riddle-demo.com/wp-login.php?interim-login=1&wp_lang=en_US";s:20:"HTTP_ACCEPT_ENCODING";s:13:"gzip, deflate";s:20:"HTTP_ACCEPT_LANGUAGE";s:14:"en-US,en;q=0.9";s:11:"HTTP_COOKIE";s:259:"wordpress_test_cookie=WP+Cookie+check; wordpress_logged_in_4b7aa5be6cf2339f4ca5e67a9c88573e=1p21.admin%7C1527962445%7C4TOMVMURuQe6xt6SoenWwrM5k1RQFB4PNPVvCASqYeN%7Cdb8644eab168d844c09000f29b1419cdbda41219814a5c9e1b53bc10fea934d1; wp-settings-time-1=1527892094";s:4:"PATH";s:29:"/usr/bin:/bin:/usr/sbin:/sbin";s:16:"SERVER_SIGNATURE";s:0:"";s:11:"SERVER_NAME";s:15:"riddle-demo.com";s:11:"SERVER_ADDR";s:3:"::1";s:11:"SERVER_PORT";s:2:"80";s:11:"REMOTE_ADDR";s:3:"::1";s:13:"DOCUMENT_ROOT";s:32:"/Applications/MAMP/htdocs/riddle";s:12:"SERVER_ADMIN";s:15:"you@example.com";s:15:"SCRIPT_FILENAME";s:45:"/Applications/MAMP/htdocs/riddle/wp-login.php";s:11:"REMOTE_PORT";s:5:"63529";s:17:"GATEWAY_INTERFACE";s:7:"CGI/1.1";s:15:"SERVER_PROTOCOL";s:8:"HTTP/1.1";s:14:"REQUEST_METHOD";s:4:"POST";s:12:"QUERY_STRING";s:0:"";s:11:"SCRIPT_NAME";s:13:"/wp-login.php";s:8:"PHP_SELF";s:13:"/wp-login.php";s:18:"REQUEST_TIME_FLOAT";s:14:"1528144496.149";s:12:"REQUEST_TIME";s:10:"1528144496";s:4:"argv";a:0:{}s:4:"argc";s:1:"0";}}', 'notice', '2018-06-04 20:34:57', '2018-06-04 20:34:56', 36760720, 36905368, 'http://riddle-demo.com/wp-login.php', 1, 0, '::1') ;

#
# End of data contents of table `wp_itsec_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_itsec_temp`
#

DROP TABLE IF EXISTS `wp_itsec_temp`;


#
# Table structure of table `wp_itsec_temp`
#

CREATE TABLE `wp_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_itsec_temp`
#
INSERT INTO `wp_itsec_temp` ( `temp_id`, `temp_type`, `temp_date`, `temp_date_gmt`, `temp_host`, `temp_user`, `temp_username`) VALUES
(1, 'brute_force', '2018-06-04 20:34:56', '2018-06-04 20:34:56', '::1', NULL, NULL),
(2, 'brute_force', '2018-06-04 20:34:56', '2018-06-04 20:34:56', NULL, 1, '1p21.admin') ;

#
# End of data contents of table `wp_itsec_temp`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=950 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://riddle-demo.com', 'yes'),
(2, 'home', 'http://riddle-demo.com', 'yes'),
(3, 'blogname', 'Riddle &amp; Brantley LLP', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1pointinteractive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:13:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:57:"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php";i:2;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:3;s:34:"advanced-custom-fields-pro/acf.php";i:4;s:19:"akismet/akismet.php";i:5;s:41:"better-wp-security/better-wp-security.php";i:6;s:19:"bugherd/bugherd.php";i:7;s:19:"mailgun/mailgun.php";i:8;s:38:"post-duplicator/m4c-postduplicator.php";i:9;s:24:"simple-history/index.php";i:10;s:24:"wordpress-seo/wp-seo.php";i:11;s:63:"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php";i:12;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'riddle', 'yes'),
(41, 'stylesheet', 'riddle', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:41:"better-wp-security/better-wp-security.php";a:2:{i:0;s:10:"ITSEC_Core";i:1;s:16:"handle_uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '60', 'yes'),
(84, 'page_on_front', '5', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'initial_db_version', '38590', 'yes'),
(93, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes'),
(94, 'fresh_site', '0', 'yes'),
(95, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:3:{s:5:"title";s:15:"Recent Articles";s:6:"number";i:5;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:7:"Archive";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:1:{i:0;s:14:"recent-posts-2";}s:16:"category_sidebar";a:1:{i:0;s:12:"categories-2";}s:15:"archive_sidebar";a:1:{i:0;s:10:"archives-2";}s:13:"array_version";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'cron', 'a:13:{i:1528217806;a:1:{s:10:"itsec_cron";a:0:{}}i:1528218886;a:1:{s:10:"itsec_cron";a:0:{}}i:1528240708;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1528255108;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1528265311;a:1:{s:15:"itsec_cron_test";a:1:{s:32:"a70ffb188fef933f88f10b4f48238aca";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:1528265311;}}}}i:1528298317;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1528298963;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1528304266;a:1:{s:10:"itsec_cron";a:1:{s:32:"7a0fd5d064c59cf40c3df9ad0bb6e63d";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:1:{i:0;s:11:"clear-locks";}s:8:"interval";i:86400;}}}i:1528304566;a:1:{s:10:"itsec_cron";a:1:{s:32:"3ec3d6914daf50bcdb5e5b065213e29b";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:1:{i:0;s:17:"purge-log-entries";}s:8:"interval";i:86400;}}}i:1528304866;a:1:{s:10:"itsec_cron";a:1:{s:32:"aa768a35ceed34e467f270ebdc5d82f4";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:1:{i:0;s:14:"purge-lockouts";}s:8:"interval";i:86400;}}}i:1528308076;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1528308096;a:2:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:29:"simple_history/maybe_purge_db";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(123, 'can_compress_scripts', '1', 'no'),
(134, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1527175132;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(135, 'current_theme', '', 'yes'),
(136, 'theme_mods_riddle', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main_menu";i:2;s:7:"pa_menu";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(145, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(173, 'recently_activated', 'a:0:{}', 'yes'),
(175, 'rg_form_version', '2.3.2', 'yes'),
(176, 'gform_enable_background_updates', '1', 'yes'),
(177, 'gform_pending_installation', '', 'yes'),
(178, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(179, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(180, 'gform_version_info', 'a:10:{s:12:"is_valid_key";b:1;s:6:"reason";s:0:"";s:7:"version";s:5:"2.3.2";s:3:"url";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=6Gw9F4GzdYg%2BQkc6RFdYryJ85cY%3D";s:15:"expiration_time";i:1538456400;s:9:"offerings";a:46:{s:12:"gravityforms";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"2.3.2";s:14:"version_latest";s:7:"2.3.2.2";s:3:"url";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=6Gw9F4GzdYg%2BQkc6RFdYryJ85cY%3D";s:10:"url_latest";s:168:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=naJgW2XGqkzmWTI32c%2FwLKhg5K0%3D";}s:26:"gravityformsactivecampaign";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:5:"1.4.5";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=W9LAQYUMUGTd%2F8LM5nC%2BU%2FlgmLk%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=R1s7K7H3HVuhW%2FLyRa%2FqDU%2Beivw%3D";}s:20:"gravityformsagilecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=T%2ByiEC%2FPVAYSscRYLjMI9H9BKbA%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=T%2ByiEC%2FPVAYSscRYLjMI9H9BKbA%3D";}s:24:"gravityformsauthorizenet";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:3:"2.6";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=ugEKKjNbGqnB8w6eIIzV0Lks61A%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=ugEKKjNbGqnB8w6eIIzV0Lks61A%3D";}s:18:"gravityformsaweber";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.7";s:14:"version_latest";s:3:"2.7";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=NDxZaUcFjiDM9DYggTpzmzKrv%2B4%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=NDxZaUcFjiDM9DYggTpzmzKrv%2B4%3D";}s:21:"gravityformsbatchbook";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=rvJlcWc7zeFztXpj7I36ovfizEs%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=rvJlcWc7zeFztXpj7I36ovfizEs%3D";}s:18:"gravityformsbreeze";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=LTI4uwqUgCca81OXa0qs2IdaN7k%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=LTI4uwqUgCca81OXa0qs2IdaN7k%3D";}s:27:"gravityformscampaignmonitor";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.7";s:14:"version_latest";s:3:"3.7";s:3:"url";s:193:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=TBGS9%2FBwIYc3S4OEM1fC56GvEtQ%3D";s:10:"url_latest";s:193:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=TBGS9%2FBwIYc3S4OEM1fC56GvEtQ%3D";}s:20:"gravityformscampfire";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=Wbbjh8HowaQmr9zhzOXMz8Je1xw%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=hM8vvv7GTScERIpKjTVeBW0RjZE%3D";}s:22:"gravityformscapsulecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=F4azetqidzMiS%2BJos3zObnQF%2FFE%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=F4azetqidzMiS%2BJos3zObnQF%2FFE%3D";}s:26:"gravityformschainedselects";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.0";s:14:"version_latest";s:5:"1.0.9";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=bGjTdkgrl48ObJzjsuDceGxSnpE%3D";s:10:"url_latest";s:195:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=8SoPIUzN%2BffdbhhQyMRGu8%2F4vwE%3D";}s:23:"gravityformscleverreach";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=DOyHnV6Dny4dUMyrKzwke3Ij2b0%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=DOyHnV6Dny4dUMyrKzwke3Ij2b0%3D";}s:19:"gravityformscoupons";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:5:"2.6.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=k%2Fk26dxHmOPfcVhR8dwJ3aOsUeo%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=AEbTk0Vvn2iVo%2F9WsUCLDtB5abA%3D";}s:17:"gravityformsdebug";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:9:"1.0.beta8";s:3:"url";s:0:"";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=QPOZkpo5KQVmFbiI1vlNAT0jT2k%3D";}s:19:"gravityformsdropbox";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:5:"2.1.1";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=kfuE6oLUHlVKco1%2Fu5ru9Hzbn%2Fc%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=pEOpXxGet0TE08D28WdL7x%2BSA10%3D";}s:16:"gravityformsemma";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.3";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=ybS%2B4NzfOIUuPNFPz%2BnGSlUQib8%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=Y7Iu%2FgF3WaPNLy0h%2BK6bWTDpSC0%3D";}s:22:"gravityformsfreshbooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=t9aofErIFsbrdsfnweoqzGNC7tQ%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=d9A2R5tAwCUZpgPGtWdhxx%2FtLuk%3D";}s:23:"gravityformsgetresponse";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:187:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=s5rJY6Xfu%2BV3yvk5xQjWT0%2BB3w4%3D";s:10:"url_latest";s:187:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=s5rJY6Xfu%2BV3yvk5xQjWT0%2BB3w4%3D";}s:21:"gravityformsgutenberg";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"1.0-beta-4";s:14:"version_latest";s:10:"1.0-beta-4";s:3:"url";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=RfK3hO4L3V7fBeuoVSihdpbnfsk%3D";s:10:"url_latest";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=RfK3hO4L3V7fBeuoVSihdpbnfsk%3D";}s:21:"gravityformshelpscout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=0qUnFb61xMXMl5vX2g76aIwhsB0%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=0qUnFb61xMXMl5vX2g76aIwhsB0%3D";}s:20:"gravityformshighrise";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.3";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=XdEFfutU4hlvYHYZxbJoNOlHnP4%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=T96o0%2FdqkSIZEuRwBxfXsx2bALY%3D";}s:19:"gravityformshipchat";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=RESJPdnFBuP%2Bs%2BF%2BS59lTPfCr7U%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=RESJPdnFBuP%2Bs%2BF%2BS59lTPfCr7U%3D";}s:20:"gravityformsicontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=aMcfZwnBNkRAcNsCf0ATcMyuZkI%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=aMcfZwnBNkRAcNsCf0ATcMyuZkI%3D";}s:19:"gravityformslogging";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=UMrL0kjpuuK%2Bd9%2F5%2FzH0zZdIfhU%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=aI77vUdIxkcmumwzP%2BJWKR0tRRE%3D";}s:19:"gravityformsmadmimi";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=FWxjJm8HszqTVsOrvP9vcf%2FT56M%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=FWxjJm8HszqTVsOrvP9vcf%2FT56M%3D";}s:21:"gravityformsmailchimp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.3";s:14:"version_latest";s:3:"4.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=lLMDMy1T0QZp%2FXRQbdzkLlunSk4%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=lLMDMy1T0QZp%2FXRQbdzkLlunSk4%3D";}s:26:"gravityformspartialentries";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=a4GCmxwIrDunudVeFzGQYxsliIg%3D";s:10:"url_latest";s:189:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=a4GCmxwIrDunudVeFzGQYxsliIg%3D";}s:18:"gravityformspaypal";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=vlMDABR1tApQNwFQR2a0rJvsLmE%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=Sm%2BwGfS1sTzQDEMHHyYwEOHQ8T4%3D";}s:33:"gravityformspaypalexpresscheckout";a:3:{s:12:"is_available";b:0;s:7:"version";s:0:"";s:14:"version_latest";N;}s:29:"gravityformspaypalpaymentspro";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.3";s:14:"version_latest";s:5:"2.3.2";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=4WBiUNYGwyD9ydBzcg0k7P4JE1o%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=VijAfqaJQvPCqo5w0NvMJDWw828%3D";}s:21:"gravityformspaypalpro";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"1.8.1";s:14:"version_latest";s:5:"1.8.1";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=BJioO7cZ6Mxeahza86tIPz7c9co%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=BJioO7cZ6Mxeahza86tIPz7c9co%3D";}s:20:"gravityformspicatcha";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";}s:16:"gravityformspipe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:169:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=WTABzu3CeCPozyB9STaH5Jf2hsY%3D";s:10:"url_latest";s:169:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=WTABzu3CeCPozyB9STaH5Jf2hsY%3D";}s:17:"gravityformspolls";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=jtj2D656rjNdKRluVn%2FCHWgSN8A%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=h6muS5adVBctDEC7dZQi0SnQgcM%3D";}s:16:"gravityformsquiz";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.7";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=MagTeBGjyJ6ish%2FPATFj4deTJ88%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=viY9ViGZxG7FLBL1aRg%2BQ8SkP54%3D";}s:19:"gravityformsrestapi";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"2.0-beta-2";s:14:"version_latest";s:10:"2.0-beta-2";s:3:"url";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=OK%2Be1LuFdH2QahPmeSs2kYFkL38%3D";s:10:"url_latest";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=OK%2Be1LuFdH2QahPmeSs2kYFkL38%3D";}s:21:"gravityformssignature";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"3.5.1";s:14:"version_latest";s:5:"3.5.2";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=eGFYdU9ZGQmwnE5n%2Boc0%2BrSYb2g%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=eTppwmf4cL1Rf8nlMGGRFIxdBYc%3D";}s:17:"gravityformsslack";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.8";s:14:"version_latest";s:3:"1.8";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=WmdWYn6hXlXfoycl0dAJF49pGsk%3D";s:10:"url_latest";s:171:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=WmdWYn6hXlXfoycl0dAJF49pGsk%3D";}s:18:"gravityformsstripe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=JWKh36kTeUlL10DQLUbImll8UKk%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=TEQ7nM%2BWeowPM%2BdrVdMPTOYHGNM%3D";}s:18:"gravityformssurvey";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.2";s:14:"version_latest";s:5:"3.2.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=6eNBv2s0BSZ1gy2%2FugJv%2BfgupcQ%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=fcYi5ibONAGL8pb6ylgB21QQi9Y%3D";}s:18:"gravityformstrello";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=QyH%2FGTK%2F021VUSP%2FQNcKRk%2BEyzQ%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=FiCNK8aTJUuHZMRK%2FxaVfTIMwpM%3D";}s:18:"gravityformstwilio";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:3:"2.5";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=DS1CVhE65H%2ByX9XXs2uiVFT0lbs%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=DS1CVhE65H%2ByX9XXs2uiVFT0lbs%3D";}s:28:"gravityformsuserregistration";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:5:"3.9.2";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=wLqZe9Ck9K%2FtOEPFtzE5Puut1XY%3D";s:10:"url_latest";s:199:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=cy%2BJLwiyBfMoUNTMEE8%2FNyLfhP0%3D";}s:20:"gravityformswebhooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=Jqk9a7e03eIiNlAOgUIh05UcCAA%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=UTFMLCQBO50bfFFAAFGa6kQZ16w%3D";}s:18:"gravityformszapier";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.0";s:14:"version_latest";s:3:"3.0";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=f4oTtcXkvgzIAW4s20%2BWXPP8FoA%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=f4oTtcXkvgzIAW4s20%2BWXPP8FoA%3D";}s:19:"gravityformszohocrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=TjmHw6A4VZXfkIWojGP3DBVPqaE%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=TjmHw6A4VZXfkIWojGP3DBVPqaE%3D";}}s:9:"is_active";s:1:"1";s:14:"version_latest";s:7:"2.3.2.2";s:10:"url_latest";s:168:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=naJgW2XGqkzmWTI32c%2FwLKhg5K0%3D";s:9:"timestamp";i:1528212127;}', 'yes'),
(198, 'mailgun', 'a:11:{s:6:"useAPI";s:1:"1";s:6:"apiKey";s:0:"";s:6:"domain";s:0:"";s:8:"username";s:0:"";s:8:"password";s:0:"";s:6:"secure";s:1:"1";s:12:"track-clicks";s:0:"";s:11:"track-opens";s:0:"";s:11:"campaign-id";s:0:"";s:13:"override-from";s:1:"0";s:3:"tag";s:15:"riddle-demo.com";}', 'yes'),
(199, 'wpseo', 'a:19:{s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"7.6";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1527789695;}', 'yes'),
(200, 'wpseo_titles', 'a:64:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:17:"stripcategorybase";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:23:"display-metabox-pt-post";b:1;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:23:"display-metabox-pt-page";b:1;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:23:"post_types-post-maintax";i:0;}', 'yes'),
(201, 'wpseo_social', 'a:18:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(202, 'wpseo_flush_rewrite', '1', 'yes'),
(203, 'itsec-storage', 'a:4:{s:6:"global";a:29:{s:15:"lockout_message";s:5:"error";s:20:"user_lockout_message";s:64:"You have been locked out due to too many invalid login attempts.";s:25:"community_lockout_message";s:77:"Your IP address has been flagged as a threat by the iThemes Security network.";s:9:"blacklist";b:1;s:15:"blacklist_count";i:3;s:16:"blacklist_period";i:7;s:14:"lockout_period";i:15;s:18:"lockout_white_list";a:0:{}s:12:"log_rotation";i:60;s:17:"file_log_rotation";i:180;s:8:"log_type";s:8:"database";s:12:"log_location";s:73:"/Applications/MAMP/htdocs/riddle/wp-content/uploads/ithemes-security/logs";s:8:"log_info";s:0:"";s:14:"allow_tracking";b:0;s:11:"write_files";b:1;s:10:"nginx_file";s:43:"/Applications/MAMP/htdocs/riddle/nginx.conf";s:24:"infinitewp_compatibility";b:0;s:11:"did_upgrade";b:0;s:9:"lock_file";b:0;s:14:"proxy_override";b:0;s:14:"hide_admin_bar";b:0;s:16:"show_error_codes";b:0;s:19:"show_security_check";b:1;s:5:"build";i:4095;s:20:"activation_timestamp";i:1527789695;s:11:"cron_status";i:1;s:8:"use_cron";b:1;s:14:"cron_test_time";i:1528265311;s:25:"show_new_dashboard_notice";b:0;}s:19:"network-brute-force";a:5:{s:7:"api_key";s:0:"";s:10:"api_secret";s:0:"";s:10:"enable_ban";b:1;s:13:"updates_optin";b:1;s:7:"api_nag";b:0;}s:19:"notification-center";a:6:{s:9:"last_sent";a:1:{s:6:"digest";i:1528212124;}s:9:"resend_at";a:0:{}s:4:"data";a:1:{s:6:"digest";a:0:{}}s:11:"mail_errors";a:0:{}s:13:"notifications";a:3:{s:6:"digest";a:5:{s:8:"schedule";s:5:"daily";s:7:"enabled";b:1;s:9:"user_list";a:1:{i:0;s:18:"role:administrator";}s:15:"previous_emails";a:0:{}s:7:"subject";N;}s:7:"lockout";a:4:{s:7:"enabled";b:1;s:9:"user_list";a:1:{i:0;s:18:"role:administrator";}s:15:"previous_emails";a:0:{}s:7:"subject";N;}s:6:"backup";a:2:{s:10:"email_list";a:1:{i:0;s:29:"garrett@1pointinteractive.com";}s:7:"subject";N;}}s:12:"admin_emails";a:0:{}}s:16:"wordpress-tweaks";a:12:{s:18:"wlwmanifest_header";b:0;s:14:"edituri_header";b:0;s:12:"comment_spam";b:0;s:11:"file_editor";b:1;s:14:"disable_xmlrpc";i:0;s:22:"allow_xmlrpc_multiauth";b:0;s:8:"rest_api";s:14:"default-access";s:12:"login_errors";b:0;s:21:"force_unique_nicename";b:0;s:27:"disable_unused_author_pages";b:0;s:16:"block_tabnapping";b:0;s:21:"valid_user_login_type";s:4:"both";}}', 'yes'),
(210, 'simple_history_db_version', '5', 'yes'),
(211, 'simple_history_show_as_page', '1', 'yes'),
(212, 'simple_history_show_on_dashboard', '1', 'yes'),
(213, 'simple_history_enable_rss_feed', '0', 'yes'),
(214, 'simple_history_rss_secret', 'zwpfzxjbxfzgwpomiktz', 'yes'),
(215, 'itsec_temp_whitelist_ip', 'a:1:{s:3:"::1";i:1528324191;}', 'no'),
(216, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(217, 'widget_list_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(221, 'acf_version', '5.6.10', 'yes'),
(222, 'mtphr_post_duplicator_settings', '', 'yes'),
(227, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(228, 'gf_site_key', '76ab56b8-9502-404f-b139-e278c4dfc0b6', 'yes'),
(229, 'gf_site_secret', '90235a73-e975-4e48-8e2e-b4fa9b2790ea', 'yes'),
(230, 'rg_gforms_enable_akismet', '1', 'yes'),
(231, 'rg_gforms_currency', 'USD', 'yes'),
(232, 'gform_enable_toolbar_menu', '1', 'yes'),
(254, 'rg_gforms_disable_css', '1', 'yes'),
(255, 'rg_gforms_captcha_public_key', '', 'yes'),
(256, 'rg_gforms_captcha_private_key', '', 'yes'),
(257, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(285, 'wpseo_sitemap_1_cache_validator', '6Gggw', 'no'),
(286, 'wpseo_sitemap_page_cache_validator', '6Gggy', 'no'),
(297, 'simplehistory_AvailableUpdatesLogger_plugin_updates_available', 'a:8:{s:19:"akismet/akismet.php";a:1:{s:15:"checked_version";s:5:"4.0.7";}s:41:"better-wp-security/better-wp-security.php";a:1:{s:15:"checked_version";s:5:"7.0.1";}s:19:"mailgun/mailgun.php";a:1:{s:15:"checked_version";s:6:"1.5.11";}s:24:"simple-history/index.php";a:1:{s:15:"checked_version";s:6:"2.23.1";}s:27:"wp-super-cache/wp-cache.php";a:1:{s:15:"checked_version";s:5:"1.6.1";}s:24:"wordpress-seo/wp-seo.php";a:1:{s:15:"checked_version";s:3:"7.6";}s:29:"gravityforms/gravityforms.php";a:1:{s:15:"checked_version";s:5:"2.3.2";}s:41:"acf-theme-code-pro/acf_theme_code_pro.php";a:1:{s:15:"checked_version";s:5:"2.3.0";}}', 'yes'),
(305, 'wpseo_sitemap_post_cache_validator', '5pvmb', 'no'),
(351, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1528239304;}', 'no'),
(381, 'wpseo_sitemap_nav_menu_item_cache_validator', '5DTwc', 'no'),
(394, 'dd9b23a13775ccc12b5389d301f8ef5d', 'a:2:{s:7:"timeout";i:1528250089;s:5:"value";s:7062:"{"new_version":"2.3.0","stable_version":"2.3.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2018-02-12 17:47:26","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"","download_link":"","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<li>Range field<\\/li>\\n<li>Button field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6.8 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.9.4 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.3.0\\u00a0released in February 2018<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.3.0<\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p>2.2.0<\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(443, 'wpseo_sitemap_category_cache_validator', '5pvmd', 'no'),
(445, 'wpseo_sitemap_62_cache_validator', '5mvI', 'no'),
(460, 'category_children', 'a:0:{}', 'yes'),
(462, 'wpseo_sitemap_64_cache_validator', 'KA3M', 'no'),
(469, 'wpseo_sitemap_66_cache_validator', 'KM7J', 'no'),
(533, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoyMjoiaHR0cDovL3JpZGRsZS1kZW1vLmNvbSI7fQ==', 'yes'),
(542, 'gf_previous_db_version', '2.3.1', 'yes'),
(543, 'gf_upgrade_lock', '', 'yes'),
(544, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(546, 'gf_db_version', '2.3.2', 'yes'),
(550, 'itsec_cron', 'a:2:{s:6:"single";a:1:{s:11:"file-change";a:2:{s:32:"06b02d1205fd2f91de80a18415634069";a:1:{s:4:"data";a:4:{s:4:"step";s:9:"get-files";s:5:"chunk";s:5:"admin";s:10:"loop_start";i:1528217806;s:9:"loop_item";i:1;}}s:32:"703181a21648f3a06ef850b0bb47d2e6";a:1:{s:4:"data";a:4:{s:4:"step";s:9:"get-files";s:5:"chunk";s:5:"admin";s:10:"loop_start";i:1528218886;s:9:"loop_item";i:1;}}}}s:9:"recurring";a:3:{s:17:"purge-log-entries";a:1:{s:4:"data";a:0:{}}s:14:"purge-lockouts";a:1:{s:4:"data";a:0:{}}s:11:"clear-locks";a:1:{s:4:"data";a:0:{}}}}', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(564, 'rewrite_rules', 'a:94:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(565, 'wpseo_sitemap_cache_validator_global', '5n1KW', 'no'),
(570, 'wpseo_sitemap_acf-field-group_cache_validator', 'zkC7', 'no'),
(571, 'wpseo_sitemap_acf-field_cache_validator', 'zkC6', 'no'),
(580, 'wpseo_sitemap_attachment_cache_validator', '6Cfyh', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_last', '1'),
(4, 5, '_edit_lock', '1527175628:1'),
(5, 5, '_wp_page_template', 'page-home.php'),
(6, 2, '_wp_trash_meta_status', 'publish'),
(7, 2, '_wp_trash_meta_time', '1527175881'),
(8, 2, '_wp_desired_post_slug', 'sample-page'),
(9, 1, '_wp_trash_meta_status', 'publish'),
(10, 1, '_wp_trash_meta_time', '1527175973'),
(11, 1, '_wp_desired_post_slug', 'hello-world'),
(12, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(13, 9, '_edit_last', '1'),
(14, 9, '_wp_page_template', 'default'),
(15, 9, '_edit_lock', '1527183766:1'),
(16, 11, '_edit_last', '1'),
(17, 11, '_wp_page_template', 'default'),
(18, 11, '_edit_lock', '1527183782:1'),
(19, 13, '_edit_last', '1'),
(20, 13, '_wp_page_template', 'default'),
(21, 13, '_edit_lock', '1528220639:1'),
(22, 15, '_edit_last', '1'),
(23, 15, '_edit_lock', '1527183803:1'),
(24, 15, '_wp_page_template', 'default'),
(25, 17, '_edit_last', '1'),
(26, 17, '_wp_page_template', 'default'),
(27, 17, '_edit_lock', '1527183813:1'),
(28, 19, '_edit_last', '1'),
(29, 19, '_wp_page_template', 'page-caseresults.php'),
(30, 19, '_edit_lock', '1528235392:1'),
(31, 21, '_edit_last', '1'),
(32, 21, '_wp_page_template', 'default'),
(33, 21, '_edit_lock', '1527183869:1'),
(34, 23, '_menu_item_type', 'post_type'),
(35, 23, '_menu_item_menu_item_parent', '0'),
(36, 23, '_menu_item_object_id', '5'),
(37, 23, '_menu_item_object', 'page'),
(38, 23, '_menu_item_target', ''),
(39, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(40, 23, '_menu_item_xfn', ''),
(41, 23, '_menu_item_url', ''),
(43, 24, '_menu_item_type', 'post_type'),
(44, 24, '_menu_item_menu_item_parent', '32'),
(45, 24, '_menu_item_object_id', '9'),
(46, 24, '_menu_item_object', 'page'),
(47, 24, '_menu_item_target', ''),
(48, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 24, '_menu_item_xfn', ''),
(50, 24, '_menu_item_url', ''),
(52, 25, '_menu_item_type', 'post_type'),
(53, 25, '_menu_item_menu_item_parent', '33'),
(54, 25, '_menu_item_object_id', '11'),
(55, 25, '_menu_item_object', 'page'),
(56, 25, '_menu_item_target', ''),
(57, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(58, 25, '_menu_item_xfn', ''),
(59, 25, '_menu_item_url', ''),
(61, 26, '_menu_item_type', 'post_type'),
(62, 26, '_menu_item_menu_item_parent', '0'),
(63, 26, '_menu_item_object_id', '19'),
(64, 26, '_menu_item_object', 'page'),
(65, 26, '_menu_item_target', ''),
(66, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(67, 26, '_menu_item_xfn', ''),
(68, 26, '_menu_item_url', ''),
(70, 27, '_menu_item_type', 'post_type'),
(71, 27, '_menu_item_menu_item_parent', '0'),
(72, 27, '_menu_item_object_id', '21'),
(73, 27, '_menu_item_object', 'page'),
(74, 27, '_menu_item_target', ''),
(75, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(76, 27, '_menu_item_xfn', ''),
(77, 27, '_menu_item_url', ''),
(79, 28, '_menu_item_type', 'post_type'),
(80, 28, '_menu_item_menu_item_parent', '0'),
(81, 28, '_menu_item_object_id', '5'),
(82, 28, '_menu_item_object', 'page'),
(83, 28, '_menu_item_target', ''),
(84, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(85, 28, '_menu_item_xfn', ''),
(86, 28, '_menu_item_url', ''),
(87, 28, '_menu_item_orphaned', '1527184015'),
(88, 29, '_menu_item_type', 'post_type'),
(89, 29, '_menu_item_menu_item_parent', '0'),
(90, 29, '_menu_item_object_id', '13'),
(91, 29, '_menu_item_object', 'page'),
(92, 29, '_menu_item_target', ''),
(93, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(94, 29, '_menu_item_xfn', ''),
(95, 29, '_menu_item_url', ''),
(96, 29, '_menu_item_orphaned', '1527184015'),
(97, 30, '_menu_item_type', 'post_type'),
(98, 30, '_menu_item_menu_item_parent', '0'),
(99, 30, '_menu_item_object_id', '15'),
(100, 30, '_menu_item_object', 'page'),
(101, 30, '_menu_item_target', ''),
(102, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(103, 30, '_menu_item_xfn', ''),
(104, 30, '_menu_item_url', ''),
(105, 30, '_menu_item_orphaned', '1527184015') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(106, 31, '_menu_item_type', 'post_type'),
(107, 31, '_menu_item_menu_item_parent', '0'),
(108, 31, '_menu_item_object_id', '17'),
(109, 31, '_menu_item_object', 'page'),
(110, 31, '_menu_item_target', ''),
(111, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(112, 31, '_menu_item_xfn', ''),
(113, 31, '_menu_item_url', ''),
(114, 31, '_menu_item_orphaned', '1527184015'),
(115, 32, '_menu_item_type', 'custom'),
(116, 32, '_menu_item_menu_item_parent', '0'),
(117, 32, '_menu_item_object_id', '32'),
(118, 32, '_menu_item_object', 'custom'),
(119, 32, '_menu_item_target', ''),
(120, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(121, 32, '_menu_item_xfn', ''),
(122, 32, '_menu_item_url', ''),
(124, 33, '_menu_item_type', 'custom'),
(125, 33, '_menu_item_menu_item_parent', '0'),
(126, 33, '_menu_item_object_id', '33'),
(127, 33, '_menu_item_object', 'custom'),
(128, 33, '_menu_item_target', ''),
(129, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(130, 33, '_menu_item_xfn', ''),
(131, 33, '_menu_item_url', ''),
(133, 34, '_menu_item_type', 'custom'),
(134, 34, '_menu_item_menu_item_parent', '0'),
(135, 34, '_menu_item_object_id', '34'),
(136, 34, '_menu_item_object', 'custom'),
(137, 34, '_menu_item_target', ''),
(138, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(139, 34, '_menu_item_xfn', ''),
(140, 34, '_menu_item_url', ''),
(142, 35, '_menu_item_type', 'post_type'),
(143, 35, '_menu_item_menu_item_parent', '34'),
(144, 35, '_menu_item_object_id', '15'),
(145, 35, '_menu_item_object', 'page'),
(146, 35, '_menu_item_target', ''),
(147, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(148, 35, '_menu_item_xfn', ''),
(149, 35, '_menu_item_url', ''),
(151, 36, '_menu_item_type', 'post_type'),
(152, 36, '_menu_item_menu_item_parent', '34'),
(153, 36, '_menu_item_object_id', '13'),
(154, 36, '_menu_item_object', 'page'),
(155, 36, '_menu_item_target', ''),
(156, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(157, 36, '_menu_item_xfn', ''),
(158, 36, '_menu_item_url', ''),
(160, 37, '_menu_item_type', 'post_type'),
(161, 37, '_menu_item_menu_item_parent', '0'),
(162, 37, '_menu_item_object_id', '17'),
(163, 37, '_menu_item_object', 'page'),
(164, 37, '_menu_item_target', ''),
(165, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(166, 37, '_menu_item_xfn', ''),
(167, 37, '_menu_item_url', ''),
(195, 41, '_menu_item_type', 'post_type'),
(196, 41, '_menu_item_menu_item_parent', '0'),
(197, 41, '_menu_item_object_id', '9'),
(198, 41, '_menu_item_object', 'page'),
(199, 41, '_menu_item_target', ''),
(200, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(201, 41, '_menu_item_xfn', ''),
(202, 41, '_menu_item_url', ''),
(203, 41, '_menu_item_orphaned', '1527281443'),
(204, 43, '_edit_last', '1'),
(205, 43, '_edit_lock', '1527799187:1'),
(206, 43, '_wp_page_template', 'default'),
(207, 43, '_yoast_wpseo_content_score', '60'),
(209, 15, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(210, 11, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(211, 46, '_edit_last', '1'),
(212, 46, '_wp_page_template', 'default'),
(213, 46, '_yoast_wpseo_content_score', '30'),
(214, 46, '_edit_lock', '1528144398:1'),
(215, 48, '_edit_last', '1'),
(216, 48, '_wp_page_template', 'default'),
(217, 48, '_yoast_wpseo_content_score', '30'),
(218, 48, '_edit_lock', '1528144409:1'),
(219, 50, '_edit_last', '1'),
(220, 50, '_wp_page_template', 'default'),
(221, 50, '_yoast_wpseo_content_score', '30'),
(222, 50, '_edit_lock', '1528144420:1'),
(223, 52, '_edit_last', '1'),
(224, 52, '_wp_page_template', 'default'),
(225, 52, '_yoast_wpseo_content_score', '30'),
(226, 52, '_edit_lock', '1528144430:1'),
(227, 54, '_menu_item_type', 'custom'),
(228, 54, '_menu_item_menu_item_parent', '0'),
(229, 54, '_menu_item_object_id', '54'),
(230, 54, '_menu_item_object', 'custom'),
(231, 54, '_menu_item_target', ''),
(232, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(233, 54, '_menu_item_xfn', ''),
(234, 54, '_menu_item_url', ''),
(236, 55, '_menu_item_type', 'post_type'),
(237, 55, '_menu_item_menu_item_parent', '59'),
(238, 55, '_menu_item_object_id', '52'),
(239, 55, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(240, 55, '_menu_item_target', ''),
(241, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(242, 55, '_menu_item_xfn', ''),
(243, 55, '_menu_item_url', ''),
(245, 56, '_menu_item_type', 'post_type'),
(246, 56, '_menu_item_menu_item_parent', '54'),
(247, 56, '_menu_item_object_id', '46'),
(248, 56, '_menu_item_object', 'page'),
(249, 56, '_menu_item_target', ''),
(250, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(251, 56, '_menu_item_xfn', ''),
(252, 56, '_menu_item_url', ''),
(254, 57, '_menu_item_type', 'post_type'),
(255, 57, '_menu_item_menu_item_parent', '59'),
(256, 57, '_menu_item_object_id', '50'),
(257, 57, '_menu_item_object', 'page'),
(258, 57, '_menu_item_target', ''),
(259, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(260, 57, '_menu_item_xfn', ''),
(261, 57, '_menu_item_url', ''),
(263, 58, '_menu_item_type', 'post_type'),
(264, 58, '_menu_item_menu_item_parent', '54'),
(265, 58, '_menu_item_object_id', '48'),
(266, 58, '_menu_item_object', 'page'),
(267, 58, '_menu_item_target', ''),
(268, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(269, 58, '_menu_item_xfn', ''),
(270, 58, '_menu_item_url', ''),
(272, 59, '_menu_item_type', 'custom'),
(273, 59, '_menu_item_menu_item_parent', '0'),
(274, 59, '_menu_item_object_id', '59'),
(275, 59, '_menu_item_object', 'custom'),
(276, 59, '_menu_item_target', ''),
(277, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(278, 59, '_menu_item_xfn', ''),
(279, 59, '_menu_item_url', ''),
(281, 46, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(282, 48, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(283, 50, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(284, 52, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(285, 60, '_edit_last', '1'),
(286, 60, '_edit_lock', '1528166309:1'),
(287, 60, '_wp_page_template', 'page-blog.php'),
(288, 60, '_yoast_wpseo_content_score', '30'),
(289, 62, '_edit_last', '1'),
(290, 62, '_edit_lock', '1528167152:1'),
(293, 62, '_yoast_wpseo_content_score', '30'),
(294, 62, '_yoast_wpseo_primary_category', '4'),
(295, 64, '_edit_last', '1'),
(296, 64, '_edit_lock', '1528168483:1'),
(299, 64, '_yoast_wpseo_content_score', '30'),
(300, 64, '_yoast_wpseo_primary_category', ''),
(305, 66, '_edit_last', '1'),
(306, 66, '_edit_lock', '1528167053:1'),
(309, 66, '_yoast_wpseo_content_score', '30'),
(310, 66, '_yoast_wpseo_primary_category', '6'),
(313, 68, '_edit_last', '1'),
(314, 68, '_edit_lock', '1528167053:1'),
(315, 68, '_yoast_wpseo_content_score', '30'),
(316, 68, '_yoast_wpseo_primary_category', '6'),
(319, 69, '_edit_last', '1'),
(320, 69, '_edit_lock', '1528167053:1'),
(321, 69, '_yoast_wpseo_content_score', '30'),
(322, 69, '_yoast_wpseo_primary_category', '6'),
(325, 70, '_edit_last', '1'),
(326, 70, '_edit_lock', '1528220581:1'),
(327, 70, '_yoast_wpseo_content_score', '30'),
(328, 70, '_yoast_wpseo_primary_category', '6'),
(329, 71, '_menu_item_type', 'post_type'),
(330, 71, '_menu_item_menu_item_parent', '32'),
(331, 71, '_menu_item_object_id', '60'),
(332, 71, '_menu_item_object', 'page'),
(333, 71, '_menu_item_target', ''),
(334, 71, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(335, 71, '_menu_item_xfn', ''),
(336, 71, '_menu_item_url', ''),
(345, 73, '_menu_item_type', 'post_type'),
(346, 73, '_menu_item_menu_item_parent', '0'),
(347, 73, '_menu_item_object_id', '13'),
(348, 73, '_menu_item_object', 'page'),
(349, 73, '_menu_item_target', ''),
(350, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(351, 73, '_menu_item_xfn', ''),
(352, 73, '_menu_item_url', ''),
(353, 73, '_menu_item_orphaned', '1528171913'),
(354, 74, '_menu_item_type', 'post_type'),
(355, 74, '_menu_item_menu_item_parent', '54'),
(356, 74, '_menu_item_object_id', '13'),
(357, 74, '_menu_item_object', 'page'),
(358, 74, '_menu_item_target', ''),
(359, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(360, 74, '_menu_item_xfn', ''),
(361, 74, '_menu_item_url', ''),
(363, 76, '_edit_last', '1'),
(364, 76, '_edit_lock', '1528233997:1'),
(365, 78, '_wp_attached_file', '2018/06/intl_blog_img.jpg'),
(366, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:291;s:6:"height";i:364;s:4:"file";s:25:"2018/06/intl_blog_img.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"intl_blog_img-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"intl_blog_img-240x300.jpg";s:5:"width";i:240;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(369, 70, 'featured_image', '78'),
(370, 70, '_featured_image', 'field_5b16be6abe7f9'),
(371, 79, 'featured_image', '78') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(372, 79, '_featured_image', 'field_5b16be6abe7f9'),
(376, 70, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(377, 13, '_yoast_wpseo_content_score', '30'),
(378, 13, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(379, 81, '_edit_last', '1'),
(380, 81, '_edit_lock', '1528235241:1'),
(381, 81, '_wp_page_template', 'page-profile.php'),
(382, 81, '_yoast_wpseo_content_score', '30'),
(383, 83, '_menu_item_type', 'post_type'),
(384, 83, '_menu_item_menu_item_parent', '33'),
(385, 83, '_menu_item_object_id', '81'),
(386, 83, '_menu_item_object', 'page'),
(387, 83, '_menu_item_target', ''),
(388, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(389, 83, '_menu_item_xfn', ''),
(390, 83, '_menu_item_url', ''),
(393, 84, '_edit_last', '1'),
(394, 84, '_edit_lock', '1528239134:1'),
(395, 81, 'attorney_first_name', 'Gene'),
(396, 81, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(397, 81, 'attorney_last_name', 'Riddle'),
(398, 81, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(399, 87, 'attorney_first_name', 'Gene'),
(400, 87, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(401, 87, 'attorney_last_name', 'Riddle'),
(402, 87, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(404, 81, 'attorney_position', 'Personal Injury Lawyer & Stanly County Native  |  Founder'),
(405, 81, '_attorney_position', 'field_5b1701294cd6d'),
(406, 89, 'attorney_first_name', 'Gene'),
(407, 89, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(408, 89, 'attorney_last_name', 'Riddle'),
(409, 89, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(410, 89, 'attorney_position', 'Personal Injury Lawyer & Stanly County Native&nbsp;&nbsp;|&nbsp;&nbsp;Founder'),
(411, 89, '_attorney_position', 'field_5b1701294cd6d'),
(413, 91, '_wp_attached_file', '2018/06/att.jpg'),
(414, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:558;s:6:"height";i:665;s:4:"file";s:15:"2018/06/att.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"att-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"att-252x300.jpg";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(415, 81, 'attorney_image', '91'),
(416, 81, '_attorney_image', 'field_5b17015119026'),
(417, 92, 'attorney_first_name', 'Gene'),
(418, 92, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(419, 92, 'attorney_last_name', 'Riddle'),
(420, 92, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(421, 92, 'attorney_position', 'Personal Injury Lawyer & Stanly County Native  |  Founder'),
(422, 92, '_attorney_position', 'field_5b1701294cd6d'),
(423, 92, 'attorney_image', '91'),
(424, 92, '_attorney_image', 'field_5b17015119026'),
(426, 93, 'attorney_first_name', 'Gene'),
(427, 93, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(428, 93, 'attorney_last_name', 'Riddle'),
(429, 93, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(430, 93, 'attorney_position', 'Personal Injury Lawyer & Stanly County Native  |  Founder'),
(431, 93, '_attorney_position', 'field_5b1701294cd6d'),
(432, 93, 'attorney_image', '91'),
(433, 93, '_attorney_image', 'field_5b17015119026'),
(435, 81, 'attorney_accolades_0_accolade_header', 'Education'),
(436, 81, '_attorney_accolades_0_accolade_header', 'field_5b1702868474e'),
(437, 81, 'attorney_accolades_0_accolade_list_0_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(438, 81, '_attorney_accolades_0_accolade_list_0_single_bullet', 'field_5b1702a484750'),
(439, 81, 'attorney_accolades_0_accolade_list_1_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(440, 81, '_attorney_accolades_0_accolade_list_1_single_bullet', 'field_5b1702a484750'),
(441, 81, 'attorney_accolades_0_accolade_list_2_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(442, 81, '_attorney_accolades_0_accolade_list_2_single_bullet', 'field_5b1702a484750'),
(443, 81, 'attorney_accolades_0_accolade_list_3_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(444, 81, '_attorney_accolades_0_accolade_list_3_single_bullet', 'field_5b1702a484750'),
(445, 81, 'attorney_accolades_0_accolade_list', '4'),
(446, 81, '_attorney_accolades_0_accolade_list', 'field_5b1702918474f'),
(447, 81, 'attorney_accolades_1_accolade_header', 'Bar Certification'),
(448, 81, '_attorney_accolades_1_accolade_header', 'field_5b1702868474e'),
(449, 81, 'attorney_accolades_1_accolade_list_0_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(450, 81, '_attorney_accolades_1_accolade_list_0_single_bullet', 'field_5b1702a484750'),
(451, 81, 'attorney_accolades_1_accolade_list_1_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(452, 81, '_attorney_accolades_1_accolade_list_1_single_bullet', 'field_5b1702a484750'),
(453, 81, 'attorney_accolades_1_accolade_list_2_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(454, 81, '_attorney_accolades_1_accolade_list_2_single_bullet', 'field_5b1702a484750'),
(455, 81, 'attorney_accolades_1_accolade_list_3_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(456, 81, '_attorney_accolades_1_accolade_list_3_single_bullet', 'field_5b1702a484750'),
(457, 81, 'attorney_accolades_1_accolade_list', '4'),
(458, 81, '_attorney_accolades_1_accolade_list', 'field_5b1702918474f'),
(459, 81, 'attorney_accolades', '2'),
(460, 81, '_attorney_accolades', 'field_5b1702508474d'),
(461, 98, 'attorney_first_name', 'Gene'),
(462, 98, '_attorney_first_name', 'field_5b1700a8d4ae8'),
(463, 98, 'attorney_last_name', 'Riddle'),
(464, 98, '_attorney_last_name', 'field_5b1700b2d4ae9'),
(465, 98, 'attorney_position', 'Personal Injury Lawyer & Stanly County Native  |  Founder'),
(466, 98, '_attorney_position', 'field_5b1701294cd6d'),
(467, 98, 'attorney_image', '91'),
(468, 98, '_attorney_image', 'field_5b17015119026'),
(469, 98, 'attorney_accolades_0_accolade_header', 'Education'),
(470, 98, '_attorney_accolades_0_accolade_header', 'field_5b1702868474e'),
(471, 98, 'attorney_accolades_0_accolade_list_0_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(472, 98, '_attorney_accolades_0_accolade_list_0_single_bullet', 'field_5b1702a484750'),
(473, 98, 'attorney_accolades_0_accolade_list_1_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(474, 98, '_attorney_accolades_0_accolade_list_1_single_bullet', 'field_5b1702a484750'),
(475, 98, 'attorney_accolades_0_accolade_list_2_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(476, 98, '_attorney_accolades_0_accolade_list_2_single_bullet', 'field_5b1702a484750'),
(477, 98, 'attorney_accolades_0_accolade_list_3_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(478, 98, '_attorney_accolades_0_accolade_list_3_single_bullet', 'field_5b1702a484750'),
(479, 98, 'attorney_accolades_0_accolade_list', '4'),
(480, 98, '_attorney_accolades_0_accolade_list', 'field_5b1702918474f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(481, 98, 'attorney_accolades_1_accolade_header', 'Bar Certification'),
(482, 98, '_attorney_accolades_1_accolade_header', 'field_5b1702868474e'),
(483, 98, 'attorney_accolades_1_accolade_list_0_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(484, 98, '_attorney_accolades_1_accolade_list_0_single_bullet', 'field_5b1702a484750'),
(485, 98, 'attorney_accolades_1_accolade_list_1_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(486, 98, '_attorney_accolades_1_accolade_list_1_single_bullet', 'field_5b1702a484750'),
(487, 98, 'attorney_accolades_1_accolade_list_2_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(488, 98, '_attorney_accolades_1_accolade_list_2_single_bullet', 'field_5b1702a484750'),
(489, 98, 'attorney_accolades_1_accolade_list_3_single_bullet', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt'),
(490, 98, '_attorney_accolades_1_accolade_list_3_single_bullet', 'field_5b1702a484750'),
(491, 98, 'attorney_accolades_1_accolade_list', '4'),
(492, 98, '_attorney_accolades_1_accolade_list', 'field_5b1702918474f'),
(493, 98, 'attorney_accolades', '2'),
(494, 98, '_attorney_accolades', 'field_5b1702508474d'),
(495, 81, '_yoast_wpseo_post_image_cache', 'a:0:{}'),
(496, 19, '_yoast_wpseo_post_image_cache', 'a:0:{}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-05-24 15:18:28', '2018-05-24 15:18:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-05-24 15:32:53', '2018-05-24 15:32:53', '', 0, 'http://riddle-demo.com/?p=1', 0, 'post', '', 1),
(2, 1, '2018-05-24 15:18:28', '2018-05-24 15:18:28', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://riddle-demo.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-05-24 15:31:21', '2018-05-24 15:31:21', '', 0, 'http://riddle-demo.com/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-05-24 15:18:28', '2018-05-24 15:18:28', '<h2>Who we are</h2><p>Our website address is: http://riddle-demo.com.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracing your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-05-24 15:18:28', '2018-05-24 15:18:28', '', 0, 'http://riddle-demo.com/?page_id=3', 0, 'page', '', 0),
(5, 1, '2018-05-24 15:29:30', '2018-05-24 15:29:30', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2018-05-24 15:29:30', '2018-05-24 15:29:30', '', 0, 'http://riddle-demo.com/?page_id=5', 0, 'page', '', 0),
(6, 1, '2018-05-24 15:29:30', '2018-05-24 15:29:30', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-05-24 15:29:30', '2018-05-24 15:29:30', '', 5, 'http://riddle-demo.com/2018/05/24/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2018-05-24 15:31:21', '2018-05-24 15:31:21', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://riddle-demo.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-05-24 15:31:21', '2018-05-24 15:31:21', '', 2, 'http://riddle-demo.com/2018/05/24/2-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-05-24 15:32:53', '2018-05-24 15:32:53', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-05-24 15:32:53', '2018-05-24 15:32:53', '', 1, 'http://riddle-demo.com/2018/05/24/1-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2018-05-24 17:45:07', '2018-05-24 17:45:07', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2018-05-24 17:45:07', '2018-05-24 17:45:07', '', 0, 'http://riddle-demo.com/?page_id=9', 0, 'page', '', 0),
(10, 1, '2018-05-24 17:45:07', '2018-05-24 17:45:07', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2018-05-24 17:45:07', '2018-05-24 17:45:07', '', 9, 'http://riddle-demo.com/2018/05/24/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2018-05-24 17:45:24', '2018-05-24 17:45:24', '', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2018-05-24 17:45:24', '2018-05-24 17:45:24', '', 0, 'http://riddle-demo.com/?page_id=11', 0, 'page', '', 0),
(12, 1, '2018-05-24 17:45:24', '2018-05-24 17:45:24', '', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-05-24 17:45:24', '2018-05-24 17:45:24', '', 11, 'http://riddle-demo.com/2018/05/24/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2018-05-24 17:45:34', '2018-05-24 17:45:34', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n			\r\n			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<h2>H2 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</h2>\r\n\r\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas <a href="">embedded link </a> aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\r\n\r\n\r\n<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</blockquote>\r\n\r\n<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur:</p>\r\n\r\n<ul>\r\n	<li>Excepteur sint occ Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.aecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</li>\r\n	<li>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium</li>\r\n	<li>am rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</li> \r\n</ul>\r\n<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p> \r\n\r\n<h3>H3 Lorem ipsum dolor sit amet, consectetur ad</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2018-06-05 17:45:47', '2018-06-05 17:45:47', '', 0, 'http://riddle-demo.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2018-05-24 17:45:34', '2018-05-24 17:45:34', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-05-24 17:45:34', '2018-05-24 17:45:34', '', 13, 'http://riddle-demo.com/2018/05/24/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2018-05-24 17:45:45', '2018-05-24 17:45:45', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-05-24 17:45:45', '2018-05-24 17:45:45', '', 0, 'http://riddle-demo.com/?page_id=15', 0, 'page', '', 0),
(16, 1, '2018-05-24 17:45:45', '2018-05-24 17:45:45', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-05-24 17:45:45', '2018-05-24 17:45:45', '', 15, 'http://riddle-demo.com/2018/05/24/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2018-05-24 17:45:55', '2018-05-24 17:45:55', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-05-24 17:45:55', '2018-05-24 17:45:55', '', 0, 'http://riddle-demo.com/?page_id=17', 0, 'page', '', 0),
(18, 1, '2018-05-24 17:45:55', '2018-05-24 17:45:55', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2018-05-24 17:45:55', '2018-05-24 17:45:55', '', 17, 'http://riddle-demo.com/2018/05/24/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-05-24 17:46:04', '2018-05-24 17:46:04', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2018-06-05 21:49:52', '2018-06-05 21:49:52', '', 0, 'http://riddle-demo.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2018-05-24 17:46:04', '2018-05-24 17:46:04', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-05-24 17:46:04', '2018-05-24 17:46:04', '', 19, 'http://riddle-demo.com/2018/05/24/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2018-05-24 17:46:13', '2018-05-24 17:46:13', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2018-05-24 17:46:13', '2018-05-24 17:46:13', '', 0, 'http://riddle-demo.com/?page_id=21', 0, 'page', '', 0),
(22, 1, '2018-05-24 17:46:13', '2018-05-24 17:46:13', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2018-05-24 17:46:13', '2018-05-24 17:46:13', '', 21, 'http://riddle-demo.com/2018/05/24/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=24', 3, 'nav_menu_item', '', 0),
(25, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=25', 7, 'nav_menu_item', '', 0),
(26, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=26', 12, 'nav_menu_item', '', 0),
(27, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=27', 13, 'nav_menu_item', '', 0),
(28, 1, '2018-05-24 17:46:55', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-24 17:46:55', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2018-05-24 17:46:55', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-24 17:46:55', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2018-05-24 17:46:55', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-24 17:46:55', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2018-05-24 17:46:55', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-24 17:46:55', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', '', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=32', 2, 'nav_menu_item', '', 0),
(33, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', '', 'Our Attorneys', '', 'publish', 'closed', 'closed', '', 'our-attorneys', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=33', 5, 'nav_menu_item', '', 0),
(34, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=34', 8, 'nav_menu_item', '', 0),
(35, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=35', 10, 'nav_menu_item', '', 0),
(36, 1, '2018-05-24 17:49:58', '2018-05-24 17:49:58', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=36', 9, 'nav_menu_item', '', 0),
(37, 1, '2018-05-24 18:02:01', '2018-05-24 18:02:01', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=37', 11, 'nav_menu_item', '', 0),
(41, 1, '2018-05-25 20:50:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-05-25 20:50:43', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2018-05-31 18:00:45', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-05-31 18:00:45', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?page_id=42', 0, 'page', '', 0),
(43, 1, '2018-05-31 20:41:54', '2018-05-31 20:41:54', 'Thanks for contacting us! We will get back to you shorty.', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2018-05-31 20:41:54', '2018-05-31 20:41:54', '', 0, 'http://riddle-demo.com/?page_id=43', 0, 'page', '', 0),
(44, 1, '2018-05-31 20:41:54', '2018-05-31 20:41:54', 'Thanks for contacting us! We will get back to you shorty.', 'Thank You', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-05-31 20:41:54', '2018-05-31 20:41:54', '', 43, 'http://riddle-demo.com/2018/05/31/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-06-01 22:08:42', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-06-01 22:08:42', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=45', 0, 'post', '', 0),
(46, 1, '2018-06-04 20:35:32', '2018-06-04 20:35:32', '', 'PA One', '', 'publish', 'closed', 'closed', '', 'pa-one', '', '', '2018-06-04 20:35:32', '2018-06-04 20:35:32', '', 0, 'http://riddle-demo.com/?page_id=46', 0, 'page', '', 0),
(47, 1, '2018-06-04 20:35:32', '2018-06-04 20:35:32', '', 'PA One', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-06-04 20:35:32', '2018-06-04 20:35:32', '', 46, 'http://riddle-demo.com/2018/06/04/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-06-04 20:35:49', '2018-06-04 20:35:49', '', 'PA Two', '', 'publish', 'closed', 'closed', '', 'pa-two', '', '', '2018-06-04 20:35:49', '2018-06-04 20:35:49', '', 0, 'http://riddle-demo.com/?page_id=48', 0, 'page', '', 0),
(49, 1, '2018-06-04 20:35:49', '2018-06-04 20:35:49', '', 'PA Two', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-06-04 20:35:49', '2018-06-04 20:35:49', '', 48, 'http://riddle-demo.com/2018/06/04/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-06-04 20:36:00', '2018-06-04 20:36:00', '', 'PA Three', '', 'publish', 'closed', 'closed', '', 'pa-three', '', '', '2018-06-04 20:36:00', '2018-06-04 20:36:00', '', 0, 'http://riddle-demo.com/?page_id=50', 0, 'page', '', 0),
(51, 1, '2018-06-04 20:36:00', '2018-06-04 20:36:00', '', 'PA Three', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-06-04 20:36:00', '2018-06-04 20:36:00', '', 50, 'http://riddle-demo.com/2018/06/04/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-06-04 20:36:09', '2018-06-04 20:36:09', '', 'Pa Four', '', 'publish', 'closed', 'closed', '', 'pa-four', '', '', '2018-06-04 20:36:09', '2018-06-04 20:36:09', '', 0, 'http://riddle-demo.com/?page_id=52', 0, 'page', '', 0),
(53, 1, '2018-06-04 20:36:09', '2018-06-04 20:36:09', '', 'Pa Four', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-06-04 20:36:09', '2018-06-04 20:36:09', '', 52, 'http://riddle-demo.com/2018/06/04/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2018-06-04 20:38:38', '2018-06-04 20:38:38', '', 'PA Title', '', 'publish', 'closed', 'closed', '', 'pa-title', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=54', 1, 'nav_menu_item', '', 0),
(55, 1, '2018-06-04 20:38:39', '2018-06-04 20:38:39', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=55', 7, 'nav_menu_item', '', 0),
(56, 1, '2018-06-04 20:38:39', '2018-06-04 20:38:39', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=56', 2, 'nav_menu_item', '', 0),
(57, 1, '2018-06-04 20:38:39', '2018-06-04 20:38:39', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=57', 6, 'nav_menu_item', '', 0),
(58, 1, '2018-06-04 20:38:39', '2018-06-04 20:38:39', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=58', 3, 'nav_menu_item', '', 0),
(59, 1, '2018-06-04 20:38:39', '2018-06-04 20:38:39', '', 'PA Title Two', '', 'publish', 'closed', 'closed', '', 'pa-title-two', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=59', 5, 'nav_menu_item', '', 0),
(60, 1, '2018-06-05 02:40:48', '2018-06-05 02:40:48', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-06-05 02:40:48', '2018-06-05 02:40:48', '', 0, 'http://riddle-demo.com/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-06-05 02:40:48', '2018-06-05 02:40:48', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-06-05 02:40:48', '2018-06-05 02:40:48', '', 60, 'http://riddle-demo.com/2018/06/05/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-06-05 02:44:38', '2018-06-05 02:44:38', 'The Takata Airbag Recall is considered the largest auto safety recall in United States history. The recall involves nearly 50 million airbags in cars, trucks, and SUVs of 19 different automakers. Caused by a defective inflator, the airbags are exploding when deployed in an accident Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laboru.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Takata Airbag Recall: The Largest Auto Recall in US History', '', 'publish', 'open', 'open', '', 'takata-airbag-recall-the-largest-auto-recall-in-us-history', '', '', '2018-06-05 02:52:32', '2018-06-05 02:52:32', '', 0, 'http://riddle-demo.com/?p=62', 0, 'post', '', 0),
(63, 1, '2018-06-05 02:44:38', '2018-06-05 02:44:38', 'The Takata Airbag Recall is considered the largest auto safety recall in United States history. The recall involves nearly 50 million airbags in cars, trucks, and SUVs of 19 different automakers. Caused by a defective inflator, the airbags are exploding when deployed in an accident Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laboru.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Takata Airbag Recall: The Largest Auto Recall in US History', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-06-05 02:44:38', '2018-06-05 02:44:38', '', 62, 'http://riddle-demo.com/2018/06/05/62-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2018-06-05 02:46:01', '2018-06-05 02:46:01', 'North Carolina Governor Roy Cooper recently declared April “Distracted Driving Awareness Month”. Unfortunately, distracted driving is a major public safety concern in our state causing nearly 25,000 injuries and 152 deaths in 2017. The National Highway Traffic Safety Administration estimates over 800,000 vehicles are being operated by someone who is also using a cell phone at any given time. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Driving While Distracted? It Could Cost You.', '', 'publish', 'open', 'open', '', 'driving-while-distracted-it-could-cost-you', '', '', '2018-06-05 03:14:43', '2018-06-05 03:14:43', '', 0, 'http://riddle-demo.com/?p=64', 0, 'post', '', 0),
(65, 1, '2018-06-05 02:46:01', '2018-06-05 02:46:01', 'North Carolina Governor Roy Cooper recently declared April “Distracted Driving Awareness Month”. Unfortunately, distracted driving is a major public safety concern in our state causing nearly 25,000 injuries and 152 deaths in 2017. The National Highway Traffic Safety Administration estimates over 800,000 vehicles are being operated by someone who is also using a cell phone at any given time. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Driving While Distracted? It Could Cost You.', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2018-06-05 02:46:01', '2018-06-05 02:46:01', '', 64, 'http://riddle-demo.com/2018/06/05/64-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2018-06-05 02:53:09', '2018-06-05 02:53:09', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post', '', 'publish', 'open', 'open', '', 'test-post', '', '', '2018-06-05 02:53:09', '2018-06-05 02:53:09', '', 0, 'http://riddle-demo.com/?p=66', 0, 'post', '', 0),
(67, 1, '2018-06-05 02:53:09', '2018-06-05 02:53:09', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2018-06-05 02:53:09', '2018-06-05 02:53:09', '', 66, 'http://riddle-demo.com/2018/06/05/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-06-05 02:53:19', '2018-06-05 02:53:19', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post  Copy', '', 'publish', 'open', 'open', '', 'test-post-copy', '', '', '2018-06-05 02:53:19', '2018-06-05 02:53:19', '', 0, 'http://riddle-demo.com/2018/06/05/test-post-copy/', 0, 'post', '', 0),
(69, 1, '2018-06-05 02:53:24', '2018-06-05 02:53:24', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post  Copy  Copy', '', 'publish', 'open', 'open', '', 'test-post-copy-copy', '', '', '2018-06-05 02:53:24', '2018-06-05 02:53:24', '', 0, 'http://riddle-demo.com/2018/06/05/test-post-copy-copy/', 0, 'post', '', 0),
(70, 1, '2018-06-05 02:53:28', '2018-06-05 02:53:28', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'test-post-copy-copy-copy', '', '', '2018-06-05 16:55:43', '2018-06-05 16:55:43', '', 0, 'http://riddle-demo.com/2018/06/05/test-post-copy-copy-copy/', 0, 'post', '', 0),
(71, 1, '2018-06-05 02:54:17', '2018-06-05 02:54:17', ' ', '', '', 'publish', 'closed', 'closed', '', '71', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=71', 4, 'nav_menu_item', '', 0),
(72, 1, '2018-06-05 03:14:32', '2018-06-05 03:14:32', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2018-06-05 03:14:32', '2018-06-05 03:14:32', '', 70, 'http://riddle-demo.com/2018/06/05/70-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2018-06-05 04:11:53', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-06-05 04:11:53', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?p=73', 1, 'nav_menu_item', '', 0),
(74, 1, '2018-06-05 04:12:38', '2018-06-05 04:12:38', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2018-06-05 04:12:38', '2018-06-05 04:12:38', '', 0, 'http://riddle-demo.com/?p=74', 4, 'nav_menu_item', '', 0),
(75, 1, '2018-06-05 16:42:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-06-05 16:42:38', '0000-00-00 00:00:00', '', 0, 'http://riddle-demo.com/?page_id=75', 0, 'page', '', 0),
(76, 1, '2018-06-05 16:48:02', '2018-06-05 16:48:02', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:14:"featured_image";}s:11:"description";s:0:"";}', 'Blog', 'blog', 'publish', 'closed', 'closed', '', 'group_5b16be5f3d1d2', '', '', '2018-06-05 16:48:02', '2018-06-05 16:48:02', '', 0, 'http://riddle-demo.com/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(77, 1, '2018-06-05 16:48:02', '2018-06-05 16:48:02', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";i:400;s:10:"max_height";s:0:"";s:8:"max_size";s:3:"0.5";s:10:"mime_types";s:0:"";}', 'Featured Image', 'featured_image', 'publish', 'closed', 'closed', '', 'field_5b16be6abe7f9', '', '', '2018-06-05 16:48:02', '2018-06-05 16:48:02', '', 76, 'http://riddle-demo.com/?post_type=acf-field&p=77', 0, 'acf-field', '', 0),
(78, 1, '2018-06-05 16:49:08', '2018-06-05 16:49:08', '', 'intl_blog_img', '', 'inherit', 'open', 'closed', '', 'intl_blog_img', '', '', '2018-06-05 16:49:08', '2018-06-05 16:49:08', '', 70, 'http://riddle-demo.com/wp-content/uploads/2018/06/intl_blog_img.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2018-06-05 16:49:18', '2018-06-05 16:49:18', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test Post  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2018-06-05 16:49:18', '2018-06-05 16:49:18', '', 70, 'http://riddle-demo.com/2018/06/05/70-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2018-06-05 17:45:47', '2018-06-05 17:45:47', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n			\r\n			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<h2>H2 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</h2>\r\n\r\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas <a href="">embedded link </a> aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\r\n\r\n\r\n<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</blockquote>\r\n\r\n<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur:</p>\r\n\r\n<ul>\r\n	<li>Excepteur sint occ Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.aecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</li>\r\n	<li>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium</li>\r\n	<li>am rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</li> \r\n</ul>\r\n<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p> \r\n\r\n<h3>H3 Lorem ipsum dolor sit amet, consectetur ad</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-06-05 17:45:47', '2018-06-05 17:45:47', '', 13, 'http://riddle-demo.com/2018/06/05/13-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(81, 1, '2018-06-05 17:49:30', '2018-06-05 17:49:30', 'Gene Riddle is a founding member of Riddle &amp; Brantley, LLP, a law firm that employs 10 lawyers with more than 160 years of combined legal experience. Gene is quick to stress his family’s deep North Carolina ties. A Stanly County native, he grew up in Aberdeen after moving from Albemarle. He has practiced law in North Carolina since September 1985. Gene’s parents were both educators. His father, a longtime superintendent of Moore County Schools, encouraged him to go to law school after college.\r\n<blockquote>“My dad is probably the most honest person that was ever born,” he says. “Honest to a fault. He said we needed more honest lawyers, and I’d be a good one.”</blockquote>\r\nToday, Gene believes honesty, integrity and willingness to work hard are the bedrock principles of a good attorney. That is what he and the other lawyers at Riddle &amp; Brantley, LLP provide to their injured clients. Gene spends much of his time reviewing cases as well as instructing and supervising attorneys and paralegals. However, he also continues to directly handle cases as the lead attorney and he touches most of the personal injury cases that come into the firm.\r\n<h2>North Carolina Personal Injury Lawyer Committed to 24/7 Client Service</h2>\r\nGene is particularly proud of his firm’s pledge to respond to phone calls and e-mails 24/7. As a result, he monitors almost all inquiries received, even after hours and on weekends. Gene takes on cases that involve serious personal injury in car accidents, truck accidents, dog bites, premises liability, wrongful death and violations of Constitutional Rights. In every case, Gene’s objective is obtaining an outcome that his client believes is fair.\r\n<h2>Attorney with a Reputation for Success in State and Federal Courtrooms</h2>\r\nJustice usually means compensation for the injured party’s losses, including their pain and suffering. Still, according to Gene, in many cases the acknowledgement of the defendant’s fault or even an apology is also valuable.\r\n\r\nIn one case, Gene represented a spectator at a high school basketball game who was badly injured when bleachers he was climbing shifted. The client fell through, severely injuring his leg. The man suffered permanent injury to his leg and incurred $2,500 in medical bills. The bleachers were not pulled out properly and stabilized, leading to the accident, Gene says. However, the school system would not admit any negligence, nor would it consider any settlement. This negligence prompted a courtroom battle where Gene prevailed. In Carter v. Wayne County Board of Education, the jury returned a verdict of $250,000 for the plaintiff.\r\n\r\nGene also represented five women in a claim against a Wayne County sheriff’s deputy. These women alleged the deputy had demanded sex in return for favorable treatment for their pending criminal cases. Four of Gene’s clients settled their lawsuits against the Wayne County Sheriff’s Department and the county. One client proceeded to federal court against the deputy, alleging he had violated her Constitutional protection against cruel and unusual punishment. Gene prevailed for his client in the courtroom.\r\n\r\nIn Fordman v. Braswell, the jury awarded the plaintiff $1.5 million in actual damages and $3.5 million in punitive damages. According to news reports, after the court heard the evidence Gene presented on behalf of the plaintiff, the defense said it would no longer contest the case. Judge Terrence Boyle then dismissed the jury and imposed the judgment.\r\n<h2>Goldsboro Wrongful Death Case: “I Believe I Truly Got Justice”</h2>\r\nOn his desk, Gene keeps a photo of 16-year-old girl, her parents’ only child. The girl died after a tractor-trailer hit her car in an intersection in Goldsboro. The initial investigation of the accident supported the truck driver’s version of the facts. He said he had a green light at the time of the accident. The girl’s devastated parents were not satisfied with the truck driver’s account, so they contacted Riddle &amp; Brantley, LLP. Our investigation revealed a different story.\r\n\r\nInvestigators tracked down eyewitnesses who contradicted the truck driver. Gene then hired accident reconstructionists whose forensic work showed that the truck driver had indeed run a red light. The trucking company’s insurers agreed with the new evidence and settled, paying the grieving parents $840,000. Additionally, the truck driver faced charges for misdemeanor death by motor vehicle. He pled guilty and eventually lost his commercial driver’s license for a year.\r\n<h2>Memberships and Professional Recognition</h2>\r\nGene’s legal accomplishments have earned him several professional honors from his legal peers, including the 2014 Litigator Award. He also has a high AV Rating from Martindale-Hubbell as well as designation among the Best Attorneys of America and the American Trial Lawyers Association’s Top 100 Trial Lawyers. Additionally, he earned membership in the Million Dollar and Multi-Million Dollar Advocates Forums, based on verdicts won and settlements reached.\r\n\r\nHowever, the award Gene treasures most is the Old North State Award, which he received in 2009. The Old North State Award is presented by the North Carolina governor to individuals who have provided exemplary service and commitment to the state. Gene received it for his community service as a member and chairman of the Wayne County Board of Elections over four years.\r\n\r\nWhy does the Old North State Award mean so much to Gene? It is the state’s second-highest award. The state’s highest civilian award is induction by the governor into the Order of the Longleaf Pine in recognition of service to the state. Gene’s father received an Order of the Longleaf Pine Award upon his retirement in 1999.\r\n<h2>Family and Free Time</h2>\r\nGene and his wife have two daughters and several pets, including a Westie named “Coconut” who has been featured in several TV commercials. Church activities', 'Gene Riddle', '', 'publish', 'closed', 'closed', '', 'gene-riddle', '', '', '2018-06-05 21:39:25', '2018-06-05 21:39:25', '', 0, 'http://riddle-demo.com/?page_id=81', 0, 'page', '', 0),
(82, 1, '2018-06-05 17:49:30', '2018-06-05 17:49:30', '', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 17:49:30', '2018-06-05 17:49:30', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2018-06-05 17:50:11', '2018-06-05 17:50:11', ' ', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2018-06-05 17:50:11', '2018-06-05 17:50:11', '', 0, 'http://riddle-demo.com/?p=83', 6, 'nav_menu_item', '', 0),
(84, 1, '2018-06-05 21:30:00', '2018-06-05 21:30:00', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"page-profile.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'Attorney Bio', 'attorney-bio', 'publish', 'closed', 'closed', '', 'group_5b1700a287cb6', '', '', '2018-06-05 21:38:22', '2018-06-05 21:38:22', '', 0, 'http://riddle-demo.com/?post_type=acf-field-group&#038;p=84', 0, 'acf-field-group', '', 0),
(85, 1, '2018-06-05 21:30:00', '2018-06-05 21:30:00', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney First Name', 'attorney_first_name', 'publish', 'closed', 'closed', '', 'field_5b1700a8d4ae8', '', '', '2018-06-05 21:30:00', '2018-06-05 21:30:00', '', 84, 'http://riddle-demo.com/?post_type=acf-field&p=85', 0, 'acf-field', '', 0),
(86, 1, '2018-06-05 21:30:00', '2018-06-05 21:30:00', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Last Name', 'attorney_last_name', 'publish', 'closed', 'closed', '', 'field_5b1700b2d4ae9', '', '', '2018-06-05 21:30:00', '2018-06-05 21:30:00', '', 84, 'http://riddle-demo.com/?post_type=acf-field&p=86', 1, 'acf-field', '', 0),
(87, 1, '2018-06-05 21:30:26', '2018-06-05 21:30:26', '', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 21:30:26', '2018-06-05 21:30:26', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2018-06-05 21:31:31', '2018-06-05 21:31:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Position', 'attorney_position', 'publish', 'closed', 'closed', '', 'field_5b1701294cd6d', '', '', '2018-06-05 21:31:31', '2018-06-05 21:31:31', '', 84, 'http://riddle-demo.com/?post_type=acf-field&p=88', 2, 'acf-field', '', 0),
(89, 1, '2018-06-05 21:31:49', '2018-06-05 21:31:49', '', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 21:31:49', '2018-06-05 21:31:49', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2018-06-05 21:33:26', '2018-06-05 21:33:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:42:"Image needs to be 558px wide by 665px high";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:557;s:10:"min_height";i:664;s:8:"min_size";s:0:"";s:9:"max_width";i:559;s:10:"max_height";i:666;s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Attorney Image', 'attorney_image', 'publish', 'closed', 'closed', '', 'field_5b17015119026', '', '', '2018-06-05 21:34:20', '2018-06-05 21:34:20', '', 84, 'http://riddle-demo.com/?post_type=acf-field&#038;p=90', 3, 'acf-field', '', 0),
(91, 1, '2018-06-05 21:34:41', '2018-06-05 21:34:41', '', 'att', '', 'inherit', 'open', 'closed', '', 'att', '', '', '2018-06-05 21:34:41', '2018-06-05 21:34:41', '', 81, 'http://riddle-demo.com/wp-content/uploads/2018/06/att.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2018-06-05 21:34:49', '2018-06-05 21:34:49', '', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 21:34:49', '2018-06-05 21:34:49', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2018-06-05 21:35:50', '2018-06-05 21:35:50', 'Gene Riddle is a founding member of Riddle &amp; Brantley, LLP, a law firm that employs 10 lawyers with more than 160 years of combined legal experience. Gene is quick to stress his family’s deep North Carolina ties. A Stanly County native, he grew up in Aberdeen after moving from Albemarle. He has practiced law in North Carolina since September 1985. Gene’s parents were both educators. His father, a longtime superintendent of Moore County Schools, encouraged him to go to law school after college.\r\n<blockquote>“My dad is probably the most honest person that was ever born,” he says. “Honest to a fault. He said we needed more honest lawyers, and I’d be a good one.”</blockquote>\r\nToday, Gene believes honesty, integrity and willingness to work hard are the bedrock principles of a good attorney. That is what he and the other lawyers at Riddle &amp; Brantley, LLP provide to their injured clients. Gene spends much of his time reviewing cases as well as instructing and supervising attorneys and paralegals. However, he also continues to directly handle cases as the lead attorney and he touches most of the personal injury cases that come into the firm.\r\n<h2>North Carolina Personal Injury Lawyer Committed to 24/7 Client Service</h2>\r\nGene is particularly proud of his firm’s pledge to respond to phone calls and e-mails 24/7. As a result, he monitors almost all inquiries received, even after hours and on weekends. Gene takes on cases that involve serious personal injury in car accidents, truck accidents, dog bites, premises liability, wrongful death and violations of Constitutional Rights. In every case, Gene’s objective is obtaining an outcome that his client believes is fair.\r\n<h2>Attorney with a Reputation for Success in State and Federal Courtrooms</h2>\r\nJustice usually means compensation for the injured party’s losses, including their pain and suffering. Still, according to Gene, in many cases the acknowledgement of the defendant’s fault or even an apology is also valuable.\r\n\r\nIn one case, Gene represented a spectator at a high school basketball game who was badly injured when bleachers he was climbing shifted. The client fell through, severely injuring his leg. The man suffered permanent injury to his leg and incurred $2,500 in medical bills. The bleachers were not pulled out properly and stabilized, leading to the accident, Gene says. However, the school system would not admit any negligence, nor would it consider any settlement. This negligence prompted a courtroom battle where Gene prevailed. In Carter v. Wayne County Board of Education, the jury returned a verdict of $250,000 for the plaintiff.\r\n\r\nGene also represented five women in a claim against a Wayne County sheriff’s deputy. These women alleged the deputy had demanded sex in return for favorable treatment for their pending criminal cases. Four of Gene’s clients settled their lawsuits against the Wayne County Sheriff’s Department and the county. One client proceeded to federal court against the deputy, alleging he had violated her Constitutional protection against cruel and unusual punishment. Gene prevailed for his client in the courtroom.\r\n\r\nIn Fordman v. Braswell, the jury awarded the plaintiff $1.5 million in actual damages and $3.5 million in punitive damages. According to news reports, after the court heard the evidence Gene presented on behalf of the plaintiff, the defense said it would no longer contest the case. Judge Terrence Boyle then dismissed the jury and imposed the judgment.\r\n<h2>Goldsboro Wrongful Death Case: “I Believe I Truly Got Justice”</h2>\r\nOn his desk, Gene keeps a photo of 16-year-old girl, her parents’ only child. The girl died after a tractor-trailer hit her car in an intersection in Goldsboro. The initial investigation of the accident supported the truck driver’s version of the facts. He said he had a green light at the time of the accident. The girl’s devastated parents were not satisfied with the truck driver’s account, so they contacted Riddle &amp; Brantley, LLP. Our investigation revealed a different story.\r\n\r\nInvestigators tracked down eyewitnesses who contradicted the truck driver. Gene then hired accident reconstructionists whose forensic work showed that the truck driver had indeed run a red light. The trucking company’s insurers agreed with the new evidence and settled, paying the grieving parents $840,000. Additionally, the truck driver faced charges for misdemeanor death by motor vehicle. He pled guilty and eventually lost his commercial driver’s license for a year.\r\n<h2>Memberships and Professional Recognition</h2>\r\nGene’s legal accomplishments have earned him several professional honors from his legal peers, including the 2014 Litigator Award. He also has a high AV Rating from Martindale-Hubbell as well as designation among the Best Attorneys of America and the American Trial Lawyers Association’s Top 100 Trial Lawyers. Additionally, he earned membership in the Million Dollar and Multi-Million Dollar Advocates Forums, based on verdicts won and settlements reached.\r\n\r\nHowever, the award Gene treasures most is the Old North State Award, which he received in 2009. The Old North State Award is presented by the North Carolina governor to individuals who have provided exemplary service and commitment to the state. Gene received it for his community service as a member and chairman of the Wayne County Board of Elections over four years.\r\n\r\nWhy does the Old North State Award mean so much to Gene? It is the state’s second-highest award. The state’s highest civilian award is induction by the governor into the Order of the Longleaf Pine in recognition of service to the state. Gene’s father received an Order of the Longleaf Pine Award upon his retirement in 1999.\r\n<h2>Family and Free Time</h2>\r\nGene and his wife have two daughters and several pets, including a Westie named “Coconut” who has been featured in several TV commercials. Church activities', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 21:35:50', '2018-06-05 21:35:50', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2018-06-05 21:38:22', '2018-06-05 21:38:22', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:8:"Add List";}', 'Attorney Accolades', 'attorney_accolades', 'publish', 'closed', 'closed', '', 'field_5b1702508474d', '', '', '2018-06-05 21:38:22', '2018-06-05 21:38:22', '', 84, 'http://riddle-demo.com/?post_type=acf-field&p=94', 4, 'acf-field', '', 0),
(95, 1, '2018-06-05 21:38:22', '2018-06-05 21:38:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Accolade Header', 'accolade_header', 'publish', 'closed', 'closed', '', 'field_5b1702868474e', '', '', '2018-06-05 21:38:22', '2018-06-05 21:38:22', '', 94, 'http://riddle-demo.com/?post_type=acf-field&p=95', 0, 'acf-field', '', 0),
(96, 1, '2018-06-05 21:38:22', '2018-06-05 21:38:22', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:10:"Add Bullet";}', 'Accolade List', 'accolade_list', 'publish', 'closed', 'closed', '', 'field_5b1702918474f', '', '', '2018-06-05 21:38:22', '2018-06-05 21:38:22', '', 94, 'http://riddle-demo.com/?post_type=acf-field&p=96', 1, 'acf-field', '', 0),
(97, 1, '2018-06-05 21:38:22', '2018-06-05 21:38:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Single Bullet', 'single_bullet', 'publish', 'closed', 'closed', '', 'field_5b1702a484750', '', '', '2018-06-05 21:38:22', '2018-06-05 21:38:22', '', 96, 'http://riddle-demo.com/?post_type=acf-field&p=97', 0, 'acf-field', '', 0),
(98, 1, '2018-06-05 21:39:25', '2018-06-05 21:39:25', 'Gene Riddle is a founding member of Riddle &amp; Brantley, LLP, a law firm that employs 10 lawyers with more than 160 years of combined legal experience. Gene is quick to stress his family’s deep North Carolina ties. A Stanly County native, he grew up in Aberdeen after moving from Albemarle. He has practiced law in North Carolina since September 1985. Gene’s parents were both educators. His father, a longtime superintendent of Moore County Schools, encouraged him to go to law school after college.\r\n<blockquote>“My dad is probably the most honest person that was ever born,” he says. “Honest to a fault. He said we needed more honest lawyers, and I’d be a good one.”</blockquote>\r\nToday, Gene believes honesty, integrity and willingness to work hard are the bedrock principles of a good attorney. That is what he and the other lawyers at Riddle &amp; Brantley, LLP provide to their injured clients. Gene spends much of his time reviewing cases as well as instructing and supervising attorneys and paralegals. However, he also continues to directly handle cases as the lead attorney and he touches most of the personal injury cases that come into the firm.\r\n<h2>North Carolina Personal Injury Lawyer Committed to 24/7 Client Service</h2>\r\nGene is particularly proud of his firm’s pledge to respond to phone calls and e-mails 24/7. As a result, he monitors almost all inquiries received, even after hours and on weekends. Gene takes on cases that involve serious personal injury in car accidents, truck accidents, dog bites, premises liability, wrongful death and violations of Constitutional Rights. In every case, Gene’s objective is obtaining an outcome that his client believes is fair.\r\n<h2>Attorney with a Reputation for Success in State and Federal Courtrooms</h2>\r\nJustice usually means compensation for the injured party’s losses, including their pain and suffering. Still, according to Gene, in many cases the acknowledgement of the defendant’s fault or even an apology is also valuable.\r\n\r\nIn one case, Gene represented a spectator at a high school basketball game who was badly injured when bleachers he was climbing shifted. The client fell through, severely injuring his leg. The man suffered permanent injury to his leg and incurred $2,500 in medical bills. The bleachers were not pulled out properly and stabilized, leading to the accident, Gene says. However, the school system would not admit any negligence, nor would it consider any settlement. This negligence prompted a courtroom battle where Gene prevailed. In Carter v. Wayne County Board of Education, the jury returned a verdict of $250,000 for the plaintiff.\r\n\r\nGene also represented five women in a claim against a Wayne County sheriff’s deputy. These women alleged the deputy had demanded sex in return for favorable treatment for their pending criminal cases. Four of Gene’s clients settled their lawsuits against the Wayne County Sheriff’s Department and the county. One client proceeded to federal court against the deputy, alleging he had violated her Constitutional protection against cruel and unusual punishment. Gene prevailed for his client in the courtroom.\r\n\r\nIn Fordman v. Braswell, the jury awarded the plaintiff $1.5 million in actual damages and $3.5 million in punitive damages. According to news reports, after the court heard the evidence Gene presented on behalf of the plaintiff, the defense said it would no longer contest the case. Judge Terrence Boyle then dismissed the jury and imposed the judgment.\r\n<h2>Goldsboro Wrongful Death Case: “I Believe I Truly Got Justice”</h2>\r\nOn his desk, Gene keeps a photo of 16-year-old girl, her parents’ only child. The girl died after a tractor-trailer hit her car in an intersection in Goldsboro. The initial investigation of the accident supported the truck driver’s version of the facts. He said he had a green light at the time of the accident. The girl’s devastated parents were not satisfied with the truck driver’s account, so they contacted Riddle &amp; Brantley, LLP. Our investigation revealed a different story.\r\n\r\nInvestigators tracked down eyewitnesses who contradicted the truck driver. Gene then hired accident reconstructionists whose forensic work showed that the truck driver had indeed run a red light. The trucking company’s insurers agreed with the new evidence and settled, paying the grieving parents $840,000. Additionally, the truck driver faced charges for misdemeanor death by motor vehicle. He pled guilty and eventually lost his commercial driver’s license for a year.\r\n<h2>Memberships and Professional Recognition</h2>\r\nGene’s legal accomplishments have earned him several professional honors from his legal peers, including the 2014 Litigator Award. He also has a high AV Rating from Martindale-Hubbell as well as designation among the Best Attorneys of America and the American Trial Lawyers Association’s Top 100 Trial Lawyers. Additionally, he earned membership in the Million Dollar and Multi-Million Dollar Advocates Forums, based on verdicts won and settlements reached.\r\n\r\nHowever, the award Gene treasures most is the Old North State Award, which he received in 2009. The Old North State Award is presented by the North Carolina governor to individuals who have provided exemplary service and commitment to the state. Gene received it for his community service as a member and chairman of the Wayne County Board of Elections over four years.\r\n\r\nWhy does the Old North State Award mean so much to Gene? It is the state’s second-highest award. The state’s highest civilian award is induction by the governor into the Order of the Longleaf Pine in recognition of service to the state. Gene’s father received an Order of the Longleaf Pine Award upon his retirement in 1999.\r\n<h2>Family and Free Time</h2>\r\nGene and his wife have two daughters and several pets, including a Westie named “Coconut” who has been featured in several TV commercials. Church activities', 'Gene Riddle', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2018-06-05 21:39:25', '2018-06-05 21:39:25', '', 81, 'http://riddle-demo.com/2018/06/05/81-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history`
#

DROP TABLE IF EXISTS `wp_simple_history`;


#
# Table structure of table `wp_simple_history`
#

CREATE TABLE `wp_simple_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `logger` varchar(30) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `occasionsID` varchar(32) DEFAULT NULL,
  `initiator` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `loggerdate` (`logger`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history`
#
INSERT INTO `wp_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(1, '2018-05-31 18:01:36', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '3b4a4f2c63669a4ec7adaee4a1cb66cf', 'wp_user'),
(2, '2018-05-31 18:01:36', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '39a69b2125c292e9d9abbbc60f375705', 'wp_user'),
(3, '2018-05-31 18:01:36', 'SimpleLogger', 'info', 'Because Simple History was just recently installed, this feed does not contain much events yet. But keep the plugin activated and soon you will see detailed information about page edits, plugin updates, user logins, and much more.', '1c6ed1ff4a97400596b011813faa932f', 'wp'),
(4, '2018-05-31 18:01:36', 'SimpleLogger', 'info', 'Welcome to Simple History!\n\nThis is the main history feed. It will contain events that this plugin has logged.', '0c4babaacbe315745cbb536eaa41278c', 'wp'),
(5, '2018-05-31 18:01:37', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '3b4a4f2c63669a4ec7adaee4a1cb66cf', 'wp'),
(6, '2018-05-31 18:01:37', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '39a69b2125c292e9d9abbbc60f375705', 'wp'),
(7, '2018-05-31 20:41:35', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '19de73017ed29ddf5ff317c917b37532', 'wp_user'),
(8, '2018-05-31 20:41:54', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'e140508b5894d46786e72ae0efe49fa3', 'wp_user'),
(9, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', 'c6ddcfe8817f693b6d060efbefc017d5', 'wp'),
(10, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '3eb6ff43a9a77f46951e7084713f9da2', 'wp'),
(11, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', 'e228abe149a37f7c345f43560f600f87', 'wp'),
(12, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '35a6ccae7cf97557a309953fe9b1786c', 'wp'),
(13, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', 'f74ec3a50a9134ceba394ec063e18880', 'wp'),
(14, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '1329edbe13f7e1dd67e88867d96db102', 'wp'),
(15, '2018-06-01 14:49:47', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '20ce70b6999d0c79f34ca0247fb6046b', 'wp'),
(16, '2018-06-04 20:34:56', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(17, '2018-06-04 20:35:04', 'SimpleUserLogger', 'info', 'Logged in', 'd4a083589749fdce8656af89c5f3202d', 'wp_user'),
(18, '2018-06-04 20:35:32', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '24e11b678fcd35301333e3fb4fd5860a', 'wp_user'),
(19, '2018-06-04 20:35:49', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'ba3c9f16c54edd0b86cfe6c82004f0ad', 'wp_user'),
(20, '2018-06-04 20:36:00', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'e13cb2ecc823c9aa0e838865d09db434', 'wp_user'),
(21, '2018-06-04 20:36:09', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'dee100787ed5e62bfdb8e10cdde7667e', 'wp_user'),
(22, '2018-06-04 20:37:02', 'SimpleCategoriesLogger', 'info', 'Added term "{term_name}" in taxonomy "{term_taxonomy}"', '083c5520a581bedd87bd7d30d5bca69a', 'wp_user'),
(23, '2018-06-04 20:37:02', 'SimpleMenuLogger', 'info', 'Created menu "{menu_name}"', '8a7e1766f93c5238f8b7f11488785ac4', 'wp_user'),
(24, '2018-06-04 20:37:07', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '2c655298886d6e74ece17c0aecc6c26d', 'wp_user'),
(25, '2018-06-04 20:37:07', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '77d8ceed00b666d20adcdbadf2a85549', 'wp_user'),
(26, '2018-06-04 20:38:38', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '0978330691ab406caf04756206caf7c9', 'wp_user'),
(27, '2018-06-04 20:38:38', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '77d8ceed00b666d20adcdbadf2a85549', 'wp_user'),
(28, '2018-06-05 02:27:59', 'SimpleUserLogger', 'info', 'Logged in', 'c136ddad85a4977488cef23b353e15b4', 'wp_user'),
(29, '2018-06-05 02:28:03', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '7280332caf1aece22718b5cf9488747a', 'wp'),
(30, '2018-06-05 02:40:44', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', 'ae5d0eedc02b75ed30f04db470fb9ac6', 'wp_user'),
(31, '2018-06-05 02:40:48', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'd5e7353df2c1fd6615dd249424eeac5b', 'wp_user'),
(32, '2018-06-05 02:41:31', 'SimpleOptionsLogger', 'info', 'Updated option "{option}"', '4fc800cca6c8fcd2cf8166b1f63448d3', 'wp_user'),
(33, '2018-06-05 02:42:41', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '66dfe5495e8daeea959ccfe711eba9f9', 'wp_user'),
(34, '2018-06-05 02:44:35', 'SimpleCategoriesLogger', 'info', 'Added term "{term_name}" in taxonomy "{term_taxonomy}"', '48dfd198b7211396cfcec3bea60aaeae', 'wp_user'),
(35, '2018-06-05 02:44:38', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'be38c0a92bac2b46a23aa82651d87107', 'wp_user'),
(36, '2018-06-05 02:45:40', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '0bc5c93aa983184b542104c21c4acb42', 'wp_user'),
(37, '2018-06-05 02:46:01', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6efb2480c5fd0a9b28d31fc8439df4dd', 'wp_user'),
(38, '2018-06-05 02:46:17', 'SimpleCategoriesLogger', 'info', 'Added term "{term_name}" in taxonomy "{term_taxonomy}"', '0ff5eadfff1c13e2c3d323aea57f538a', 'wp_user'),
(39, '2018-06-05 02:46:27', 'SimpleCategoriesLogger', 'info', 'Added term "{term_name}" in taxonomy "{term_taxonomy}"', 'fcdbf9741bd1b38c732b45e18449b153', 'wp_user'),
(40, '2018-06-05 02:52:24', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6efb2480c5fd0a9b28d31fc8439df4dd', 'wp_user'),
(41, '2018-06-05 02:52:32', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'be38c0a92bac2b46a23aa82651d87107', 'wp_user'),
(42, '2018-06-05 02:52:51', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '14eb475fa8a530085320ed8ce063982c', 'wp_user'),
(43, '2018-06-05 02:53:09', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '54f96d5a783181bc16fc616cbafc6797', 'wp_user'),
(44, '2018-06-05 02:53:19', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '5633700b444ba07087c77a412851f545', 'wp_user'),
(45, '2018-06-05 02:53:24', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6cc82236043fa54c4d4de9b29e94eb42', 'wp_user'),
(46, '2018-06-05 02:53:28', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a132c950f056ad6d1268a4c4345a6cc6', 'wp_user'),
(47, '2018-06-05 02:54:17', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'b7bd44f44fdf5e48e8782a363e709d02', 'wp_user'),
(48, '2018-06-05 02:54:17', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a6f22d28053aa033160e5452441ac256', 'wp_user'),
(49, '2018-06-05 03:14:32', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a132c950f056ad6d1268a4c4345a6cc6', 'wp_user'),
(50, '2018-06-05 03:14:38', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6efb2480c5fd0a9b28d31fc8439df4dd', 'wp_user'),
(51, '2018-06-05 03:14:43', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6efb2480c5fd0a9b28d31fc8439df4dd', 'wp_user'),
(52, '2018-06-05 03:40:18', 'SimpleThemeLogger', 'info', 'Removed widget "{widget_id_base}" from sidebar "{sidebar_id}"', 'b01aec038d8091a2ff98f06d7f88d8ba', 'wp_user'),
(53, '2018-06-05 03:40:19', 'SimpleThemeLogger', 'info', 'Removed widget "{widget_id_base}" from sidebar "{sidebar_id}"', 'a39fc98fa1da0072fa93bececd343f8f', 'wp_user'),
(54, '2018-06-05 03:40:24', 'SimpleThemeLogger', 'info', 'Removed widget "{widget_id_base}" from sidebar "{sidebar_id}"', 'b2755717e7749b4744c18824b0d7d163', 'wp_user'),
(55, '2018-06-05 04:12:38', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '5af9e4af9a9a3817c63d159a12594339', 'wp_user'),
(56, '2018-06-05 04:12:38', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', '77d8ceed00b666d20adcdbadf2a85549', 'wp_user'),
(57, '2018-06-05 04:32:26', 'SimpleThemeLogger', 'info', 'Changed widget "{widget_id_base}" in sidebar "{sidebar_id}"', '1937115bb097a83df084664e2da638a2', 'wp_user'),
(58, '2018-06-05 04:32:27', 'SimpleThemeLogger', 'info', 'Changed widget "{widget_id_base}" in sidebar "{sidebar_id}"', '704ae1b6783cfb2a69d601c449a8df99', 'wp_user'),
(59, '2018-06-05 15:22:06', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '270575946b04d5979b88fb90d834f239', 'wp'),
(60, '2018-06-05 15:22:09', 'AvailableUpdatesLogger', 'notice', 'Found an update to plugin "{plugin_name}"', '270575946b04d5979b88fb90d834f239', 'wp'),
(61, '2018-06-05 16:15:01', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(62, '2018-06-05 16:42:36', 'SimpleUserLogger', 'info', 'Logged in', 'd4a083589749fdce8656af89c5f3202d', 'wp_user'),
(63, '2018-06-05 16:43:40', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '7cc6f3310af12ee91ace93dbe5256e66', 'wp_user'),
(64, '2018-06-05 16:43:46', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '367b167318f98e4b78708dfd1b36a085', 'wp_user'),
(65, '2018-06-05 16:45:44', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', 'ee280d986e74242ca8e5beeed58e8d5a', 'wp_user'),
(66, '2018-06-05 16:45:49', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '63779c94fc2377feec672ecdb5265545', 'wp_user'),
(67, '2018-06-05 16:45:54', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '270da120628bf8bbdc8d9c1c55485295', 'wp_user'),
(68, '2018-06-05 16:46:08', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '63caa9ba5056a93a847d66de2cd09676', 'wp_user'),
(69, '2018-06-05 16:46:17', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '86e552e30c91c2b3eea3b81a515817b2', 'wp_user'),
(70, '2018-06-05 16:48:02', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '7381f32ffecd47d7d38c758273b3dc9a', 'wp_user'),
(71, '2018-06-05 16:49:08', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', 'eb4ab895f069da124ec24b591483d6e1', 'wp_user'),
(72, '2018-06-05 16:49:18', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a132c950f056ad6d1268a4c4345a6cc6', 'wp_user'),
(73, '2018-06-05 16:55:43', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'a132c950f056ad6d1268a4c4345a6cc6', 'wp_user'),
(74, '2018-06-05 17:45:47', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'bdc0f0a9efd6f43324a9e84aa75c2e75', 'wp_user'),
(75, '2018-06-05 17:49:18', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '133bbf7fd62e6ece6ff043f5c9c53847', 'wp_user'),
(76, '2018-06-05 17:49:30', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(77, '2018-06-05 17:49:36', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(78, '2018-06-05 17:50:11', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'b7bd44f44fdf5e48e8782a363e709d02', 'wp_user'),
(79, '2018-06-05 17:50:11', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a6f22d28053aa033160e5452441ac256', 'wp_user'),
(80, '2018-06-05 20:19:10', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(81, '2018-06-05 21:28:51', 'SimpleUserLogger', 'info', 'Logged in', 'd4a083589749fdce8656af89c5f3202d', 'wp_user'),
(82, '2018-06-05 21:30:00', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '0540c16525ef57b5488532ad00b09d58', 'wp_user'),
(83, '2018-06-05 21:30:26', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(84, '2018-06-05 21:31:31', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'f28c0ee460d22f66e8de627176814fd3', 'wp_user'),
(85, '2018-06-05 21:31:49', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(86, '2018-06-05 21:33:26', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'f28c0ee460d22f66e8de627176814fd3', 'wp_user'),
(87, '2018-06-05 21:34:20', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'f28c0ee460d22f66e8de627176814fd3', 'wp_user'),
(88, '2018-06-05 21:34:41', 'SimpleMediaLogger', 'info', 'Created {post_type} "{attachment_title}"', '116d0ac9d8d5071f2323273489634dd6', 'wp_user'),
(89, '2018-06-05 21:34:49', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(90, '2018-06-05 21:35:50', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(91, '2018-06-05 21:38:22', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', 'f28c0ee460d22f66e8de627176814fd3', 'wp_user'),
(92, '2018-06-05 21:39:25', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '288d5275b9b3dbb8a2842e23d674dfa0', 'wp_user'),
(93, '2018-06-05 21:49:52', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '6569cd39379ffc0f754c79d386b5d558', 'wp_user') ;

#
# End of data contents of table `wp_simple_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history_contexts`
#

DROP TABLE IF EXISTS `wp_simple_history_contexts`;


#
# Table structure of table `wp_simple_history_contexts`
#

CREATE TABLE `wp_simple_history_contexts` (
  `context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`context_id`),
  KEY `history_id` (`history_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=1162 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history_contexts`
#
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1, 1, 'plugin_name', 'Simple History'),
(2, 1, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(3, 1, 'plugin_url', 'http://simple-history.com'),
(4, 1, 'plugin_version', '2.20'),
(5, 1, 'plugin_author', 'Pär Thernström'),
(6, 1, '_message_key', 'plugin_installed'),
(7, 1, '_user_id', '1'),
(8, 1, '_user_login', '1p21.admin'),
(9, 1, '_user_email', 'garrett@1pointinteractive.com'),
(10, 1, '_server_remote_addr', '::1'),
(11, 1, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php?plugin_status=all&paged=1&s'),
(12, 2, 'plugin_name', 'Simple History'),
(13, 2, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(14, 2, 'plugin_url', 'http://simple-history.com'),
(15, 2, 'plugin_version', '2.20'),
(16, 2, 'plugin_author', 'Pär Thernström'),
(17, 2, 'plugin_slug', 'simple-history'),
(18, 2, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(19, 2, '_message_key', 'plugin_activated'),
(20, 2, '_user_id', '1'),
(21, 2, '_user_login', '1p21.admin'),
(22, 2, '_user_email', 'garrett@1pointinteractive.com'),
(23, 2, '_server_remote_addr', '::1'),
(24, 2, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php?plugin_status=all&paged=1&s'),
(25, 3, '_user_id', '1'),
(26, 3, '_user_login', '1p21.admin'),
(27, 3, '_user_email', 'garrett@1pointinteractive.com'),
(28, 3, '_server_remote_addr', '::1'),
(29, 3, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php?plugin_status=all&paged=1&s'),
(30, 4, '_user_id', '1'),
(31, 4, '_user_login', '1p21.admin'),
(32, 4, '_user_email', 'garrett@1pointinteractive.com'),
(33, 4, '_server_remote_addr', '::1'),
(34, 4, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php?plugin_status=all&paged=1&s'),
(35, 5, 'plugin_name', 'Simple History'),
(36, 5, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(37, 5, 'plugin_url', 'http://simple-history.com'),
(38, 5, 'plugin_version', '2.20'),
(39, 5, 'plugin_author', 'Pär Thernström'),
(40, 5, '_message_key', 'plugin_installed'),
(41, 5, '_wp_cron_running', 'true'),
(42, 5, '_server_remote_addr', '::1'),
(43, 5, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527789696.7182469367980957031250'),
(44, 6, 'plugin_name', 'Simple History'),
(45, 6, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(46, 6, 'plugin_url', 'http://simple-history.com'),
(47, 6, 'plugin_version', '2.20'),
(48, 6, 'plugin_author', 'Pär Thernström'),
(49, 6, 'plugin_slug', 'simple-history'),
(50, 6, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(51, 6, '_message_key', 'plugin_activated'),
(52, 6, '_wp_cron_running', 'true'),
(53, 6, '_server_remote_addr', '::1'),
(54, 6, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527789696.7182469367980957031250'),
(55, 7, 'post_id', '43'),
(56, 7, 'post_type', 'page'),
(57, 7, 'post_title', 'Thank You'),
(58, 7, '_message_key', 'post_created'),
(59, 7, '_user_id', '1'),
(60, 7, '_user_login', '1p21.admin'),
(61, 7, '_user_email', 'garrett@1pointinteractive.com'),
(62, 7, '_server_remote_addr', '::1'),
(63, 7, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page'),
(64, 8, 'post_id', '43'),
(65, 8, 'post_type', 'page'),
(66, 8, 'post_title', 'Thank You'),
(67, 8, 'post_prev_post_name', ''),
(68, 8, 'post_new_post_name', 'thank-you'),
(69, 8, 'post_prev_post_content', ''),
(70, 8, 'post_new_post_content', 'Thanks for contacting us! We will get back to you shorty.'),
(71, 8, 'post_prev_post_status', 'draft'),
(72, 8, 'post_new_post_status', 'publish'),
(73, 8, 'post_prev_post_date', '2018-05-31 20:41:35'),
(74, 8, 'post_new_post_date', '2018-05-31 20:41:54'),
(75, 8, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(76, 8, 'post_new_post_date_gmt', '2018-05-31 20:41:54'),
(77, 8, '_message_key', 'post_updated'),
(78, 8, '_user_id', '1'),
(79, 8, '_user_login', '1p21.admin'),
(80, 8, '_user_email', 'garrett@1pointinteractive.com'),
(81, 8, '_server_remote_addr', '::1'),
(82, 8, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(83, 9, 'plugin_name', 'Akismet Anti-Spam'),
(84, 9, 'plugin_current_version', '4.0.3'),
(85, 9, 'plugin_new_version', '4.0.7'),
(86, 9, '_message_key', 'plugin_update_available'),
(87, 9, '_server_remote_addr', '::1'),
(88, 9, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(89, 10, 'plugin_name', 'iThemes Security'),
(90, 10, 'plugin_current_version', '6.9.2'),
(91, 10, 'plugin_new_version', '7.0.1'),
(92, 10, '_message_key', 'plugin_update_available'),
(93, 10, '_server_remote_addr', '::1'),
(94, 10, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(95, 11, 'plugin_name', 'Mailgun'),
(96, 11, 'plugin_current_version', '1.5.8.5'),
(97, 11, 'plugin_new_version', '1.5.11'),
(98, 11, '_message_key', 'plugin_update_available'),
(99, 11, '_server_remote_addr', '::1'),
(100, 11, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(101, 12, 'plugin_name', 'Simple History'),
(102, 12, 'plugin_current_version', '2.20'),
(103, 12, 'plugin_new_version', '2.23.1'),
(104, 12, '_message_key', 'plugin_update_available'),
(105, 12, '_server_remote_addr', '::1'),
(106, 12, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(107, 13, 'plugin_name', 'WP Super Cache'),
(108, 13, 'plugin_current_version', '1.6.0'),
(109, 13, 'plugin_new_version', '1.6.1'),
(110, 13, '_message_key', 'plugin_update_available'),
(111, 13, '_server_remote_addr', '::1'),
(112, 13, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(113, 14, 'plugin_name', 'Yoast SEO'),
(114, 14, 'plugin_current_version', '7.4.2'),
(115, 14, 'plugin_new_version', '7.5.3'),
(116, 14, '_message_key', 'plugin_update_available'),
(117, 14, '_server_remote_addr', '::1'),
(118, 14, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(119, 15, 'plugin_name', 'Gravity Forms'),
(120, 15, 'plugin_current_version', '2.3.1'),
(121, 15, 'plugin_new_version', '2.3.2'),
(122, 15, '_message_key', 'plugin_update_available'),
(123, 15, '_server_remote_addr', '::1'),
(124, 15, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1527864585.3470671176910400390625'),
(125, 16, 'login_id', '1'),
(126, 16, 'login_email', 'garrett@1pointinteractive.com'),
(127, 16, 'login', '1p21.admin'),
(128, 16, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'),
(129, 16, '_message_key', 'user_login_failed'),
(130, 16, '_server_remote_addr', '::1'),
(131, 16, '_server_http_referer', 'http://riddle-demo.com/wp-login.php?interim-login=1&wp_lang=en_US'),
(132, 17, 'user_id', '1'),
(133, 17, 'user_email', 'garrett@1pointinteractive.com'),
(134, 17, 'user_login', '1p21.admin'),
(135, 17, '_user_id', '1'),
(136, 17, '_user_login', '1p21.admin'),
(137, 17, '_user_email', 'garrett@1pointinteractive.com'),
(138, 17, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'),
(139, 17, '_message_key', 'user_logged_in'),
(140, 17, '_server_remote_addr', '::1'),
(141, 17, '_server_http_referer', 'http://riddle-demo.com/wp-login.php'),
(142, 18, 'post_id', '46'),
(143, 18, 'post_type', 'page'),
(144, 18, 'post_title', 'PA One'),
(145, 18, '_message_key', 'post_created'),
(146, 18, '_user_id', '1'),
(147, 18, '_user_login', '1p21.admin'),
(148, 18, '_user_email', 'garrett@1pointinteractive.com'),
(149, 18, '_server_remote_addr', '::1'),
(150, 18, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(151, 19, 'post_id', '48'),
(152, 19, 'post_type', 'page'),
(153, 19, 'post_title', 'PA Two'),
(154, 19, '_message_key', 'post_created'),
(155, 19, '_user_id', '1'),
(156, 19, '_user_login', '1p21.admin'),
(157, 19, '_user_email', 'garrett@1pointinteractive.com'),
(158, 19, '_server_remote_addr', '::1'),
(159, 19, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(160, 20, 'post_id', '50'),
(161, 20, 'post_type', 'page'),
(162, 20, 'post_title', 'PA Three'),
(163, 20, '_message_key', 'post_created'),
(164, 20, '_user_id', '1'),
(165, 20, '_user_login', '1p21.admin'),
(166, 20, '_user_email', 'garrett@1pointinteractive.com'),
(167, 20, '_server_remote_addr', '::1'),
(168, 20, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(169, 21, 'post_id', '52'),
(170, 21, 'post_type', 'page'),
(171, 21, 'post_title', 'Pa Four'),
(172, 21, '_message_key', 'post_created'),
(173, 21, '_user_id', '1'),
(174, 21, '_user_login', '1p21.admin'),
(175, 21, '_user_email', 'garrett@1pointinteractive.com'),
(176, 21, '_server_remote_addr', '::1'),
(177, 21, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(178, 22, 'term_id', '3'),
(179, 22, 'term_name', 'Practice Areas'),
(180, 22, 'term_taxonomy', 'nav_menu'),
(181, 22, '_message_key', 'created_term'),
(182, 22, '_user_id', '1'),
(183, 22, '_user_login', '1p21.admin'),
(184, 22, '_user_email', 'garrett@1pointinteractive.com'),
(185, 22, '_server_remote_addr', '::1'),
(186, 22, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=0'),
(187, 23, 'term_id', '3'),
(188, 23, 'menu_name', 'Practice Areas'),
(189, 23, '_message_key', 'created_menu'),
(190, 23, '_user_id', '1'),
(191, 23, '_user_login', '1p21.admin'),
(192, 23, '_user_email', 'garrett@1pointinteractive.com'),
(193, 23, '_server_remote_addr', '::1'),
(194, 23, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=0'),
(195, 24, 'menu_id', '3'),
(196, 24, 'menu_name', 'Practice Areas'),
(197, 24, 'menu_items_added', '0'),
(198, 24, 'menu_items_removed', '0'),
(199, 24, '_message_key', 'edited_menu'),
(200, 24, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(201, 24, '_user_login', '1p21.admin'),
(202, 24, '_user_email', 'garrett@1pointinteractive.com'),
(203, 24, '_server_remote_addr', '::1'),
(204, 24, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?menu=3'),
(205, 25, 'term_id', '3'),
(206, 25, 'from_term_name', 'Practice Areas'),
(207, 25, 'from_term_taxonomy', 'nav_menu'),
(208, 25, 'from_term_slug', 'practice-areas'),
(209, 25, 'from_term_description', ''),
(210, 25, 'to_term_name', 'Practice Areas'),
(211, 25, 'to_term_taxonomy', 'nav_menu'),
(212, 25, 'to_term_slug', 'null'),
(213, 25, 'to_term_description', ''),
(214, 25, '_message_key', 'edited_term'),
(215, 25, '_user_id', '1'),
(216, 25, '_user_login', '1p21.admin'),
(217, 25, '_user_email', 'garrett@1pointinteractive.com'),
(218, 25, '_server_remote_addr', '::1'),
(219, 25, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?menu=3'),
(220, 26, 'menu_id', '3'),
(221, 26, 'menu_name', 'Practice Areas'),
(222, 26, 'menu_items_added', '6'),
(223, 26, 'menu_items_removed', '0'),
(224, 26, '_message_key', 'edited_menu'),
(225, 26, '_user_id', '1'),
(226, 26, '_user_login', '1p21.admin'),
(227, 26, '_user_email', 'garrett@1pointinteractive.com'),
(228, 26, '_server_remote_addr', '::1'),
(229, 26, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?menu=3'),
(230, 27, 'term_id', '3'),
(231, 27, 'from_term_name', 'Practice Areas'),
(232, 27, 'from_term_taxonomy', 'nav_menu'),
(233, 27, 'from_term_slug', 'practice-areas'),
(234, 27, 'from_term_description', ''),
(235, 27, 'to_term_name', 'Practice Areas'),
(236, 27, 'to_term_taxonomy', 'nav_menu'),
(237, 27, 'to_term_slug', 'null'),
(238, 27, 'to_term_description', ''),
(239, 27, '_message_key', 'edited_term'),
(240, 27, '_user_id', '1'),
(241, 27, '_user_login', '1p21.admin'),
(242, 27, '_user_email', 'garrett@1pointinteractive.com'),
(243, 27, '_server_remote_addr', '::1'),
(244, 27, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?menu=3'),
(245, 28, 'user_id', '1'),
(246, 28, 'user_email', 'garrett@1pointinteractive.com'),
(247, 28, 'user_login', '1p21.admin'),
(248, 28, '_user_id', '1'),
(249, 28, '_user_login', '1p21.admin'),
(250, 28, '_user_email', 'garrett@1pointinteractive.com'),
(251, 28, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'),
(252, 28, '_message_key', 'user_logged_in'),
(253, 28, '_server_remote_addr', '::1'),
(254, 28, '_server_http_referer', 'http://riddle-demo.com/wp-login.php'),
(255, 29, 'plugin_name', 'Advanced Custom Fields: Theme Code Pro'),
(256, 29, 'plugin_current_version', '1.2.0'),
(257, 29, 'plugin_new_version', '2.3.0'),
(258, 29, '_message_key', 'plugin_update_available'),
(259, 29, '_user_id', '1'),
(260, 29, '_user_login', '1p21.admin'),
(261, 29, '_user_email', 'garrett@1pointinteractive.com'),
(262, 29, '_server_remote_addr', '::1'),
(263, 29, '_server_http_referer', 'http://riddle-demo.com/wp-login.php'),
(264, 30, 'post_id', '60'),
(265, 30, 'post_type', 'page'),
(266, 30, 'post_title', 'Blog'),
(267, 30, '_message_key', 'post_created'),
(268, 30, '_user_id', '1'),
(269, 30, '_user_login', '1p21.admin'),
(270, 30, '_user_email', 'garrett@1pointinteractive.com'),
(271, 30, '_server_remote_addr', '::1'),
(272, 30, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page'),
(273, 31, 'post_id', '60'),
(274, 31, 'post_type', 'page'),
(275, 31, 'post_title', 'Blog'),
(276, 31, 'post_prev_post_name', ''),
(277, 31, 'post_new_post_name', 'blog'),
(278, 31, 'post_prev_post_status', 'draft'),
(279, 31, 'post_new_post_status', 'publish'),
(280, 31, 'post_prev_post_date', '2018-06-05 02:40:44'),
(281, 31, 'post_new_post_date', '2018-06-05 02:40:48'),
(282, 31, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(283, 31, 'post_new_post_date_gmt', '2018-06-05 02:40:48'),
(284, 31, '_message_key', 'post_updated'),
(285, 31, '_user_id', '1'),
(286, 31, '_user_login', '1p21.admin'),
(287, 31, '_user_email', 'garrett@1pointinteractive.com'),
(288, 31, '_server_remote_addr', '::1'),
(289, 31, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(290, 32, 'option', 'page_for_posts'),
(291, 32, 'old_value', '0'),
(292, 32, 'new_value', '60'),
(293, 32, 'option_page', 'reading'),
(294, 32, 'new_post_title', 'Blog'),
(295, 32, '_message_key', 'option_updated'),
(296, 32, '_user_id', '1'),
(297, 32, '_user_login', '1p21.admin'),
(298, 32, '_user_email', 'garrett@1pointinteractive.com'),
(299, 32, '_server_remote_addr', '::1'),
(300, 32, '_server_http_referer', 'http://riddle-demo.com/wp-admin/options-reading.php') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(301, 33, 'post_id', '62'),
(302, 33, 'post_type', 'post'),
(303, 33, 'post_title', 'Takata Airbag Recall: The Largest Auto Recall in US History'),
(304, 33, '_message_key', 'post_created'),
(305, 33, '_user_id', '1'),
(306, 33, '_user_login', '1p21.admin'),
(307, 33, '_user_email', 'garrett@1pointinteractive.com'),
(308, 33, '_server_remote_addr', '::1'),
(309, 33, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php'),
(310, 34, 'term_id', '4'),
(311, 34, 'term_name', 'Cat 1'),
(312, 34, 'term_taxonomy', 'category'),
(313, 34, '_message_key', 'created_term'),
(314, 34, '_user_id', '1'),
(315, 34, '_user_login', '1p21.admin'),
(316, 34, '_user_email', 'garrett@1pointinteractive.com'),
(317, 34, '_server_remote_addr', '::1'),
(318, 34, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php'),
(319, 35, 'post_id', '62'),
(320, 35, 'post_type', 'post'),
(321, 35, 'post_title', 'Takata Airbag Recall: The Largest Auto Recall in US History'),
(322, 35, 'post_prev_post_name', ''),
(323, 35, 'post_new_post_name', 'takata-airbag-recall-the-largest-auto-recall-in-us-history'),
(324, 35, 'post_prev_post_content', ''),
(325, 35, 'post_new_post_content', 'The Takata Airbag Recall is considered the largest auto safety recall in United States history. The recall involves nearly 50 million airbags in cars, trucks, and SUVs of 19 different automakers. Caused by a defective inflator, the airbags are exploding when deployed in an accident Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laboru.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(326, 35, 'post_prev_post_status', 'draft'),
(327, 35, 'post_new_post_status', 'publish'),
(328, 35, 'post_prev_post_date', '2018-06-05 02:42:41'),
(329, 35, 'post_new_post_date', '2018-06-05 02:44:38'),
(330, 35, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(331, 35, 'post_new_post_date_gmt', '2018-06-05 02:44:38'),
(332, 35, '_message_key', 'post_updated'),
(333, 35, '_user_id', '1'),
(334, 35, '_user_login', '1p21.admin'),
(335, 35, '_user_email', 'garrett@1pointinteractive.com'),
(336, 35, '_server_remote_addr', '::1'),
(337, 35, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?wp-post-new-reload=true&wp-post-new-reload=true'),
(338, 36, 'post_id', '64'),
(339, 36, 'post_type', 'post'),
(340, 36, 'post_title', 'Driving While Distracted? It Could Cost You.'),
(341, 36, '_message_key', 'post_created'),
(342, 36, '_user_id', '1'),
(343, 36, '_user_login', '1p21.admin'),
(344, 36, '_user_email', 'garrett@1pointinteractive.com'),
(345, 36, '_server_remote_addr', '::1'),
(346, 36, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php'),
(347, 37, 'post_id', '64'),
(348, 37, 'post_type', 'post'),
(349, 37, 'post_title', 'Driving While Distracted? It Could Cost You.'),
(350, 37, 'post_prev_post_name', ''),
(351, 37, 'post_new_post_name', 'driving-while-distracted-it-could-cost-you'),
(352, 37, 'post_prev_post_content', ''),
(353, 37, 'post_new_post_content', 'North Carolina Governor Roy Cooper recently declared April “Distracted Driving Awareness Month”. Unfortunately, distracted driving is a major public safety concern in our state causing nearly 25,000 injuries and 152 deaths in 2017. The National Highway Traffic Safety Administration estimates over 800,000 vehicles are being operated by someone who is also using a cell phone at any given time. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(354, 37, 'post_prev_post_status', 'draft'),
(355, 37, 'post_new_post_status', 'publish'),
(356, 37, 'post_prev_post_date', '2018-06-05 02:45:40'),
(357, 37, 'post_new_post_date', '2018-06-05 02:46:01'),
(358, 37, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(359, 37, 'post_new_post_date_gmt', '2018-06-05 02:46:01'),
(360, 37, '_message_key', 'post_updated'),
(361, 37, '_user_id', '1'),
(362, 37, '_user_login', '1p21.admin'),
(363, 37, '_user_email', 'garrett@1pointinteractive.com'),
(364, 37, '_server_remote_addr', '::1'),
(365, 37, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?wp-post-new-reload=true&wp-post-new-reload=true'),
(366, 38, 'term_id', '5'),
(367, 38, 'term_name', 'Cat 2'),
(368, 38, 'term_taxonomy', 'category'),
(369, 38, '_message_key', 'created_term'),
(370, 38, '_user_id', '1'),
(371, 38, '_user_login', '1p21.admin'),
(372, 38, '_user_email', 'garrett@1pointinteractive.com'),
(373, 38, '_server_remote_addr', '::1'),
(374, 38, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit-tags.php?taxonomy=category'),
(375, 39, 'term_id', '6'),
(376, 39, 'term_name', 'Cat 3'),
(377, 39, 'term_taxonomy', 'category'),
(378, 39, '_message_key', 'created_term'),
(379, 39, '_user_id', '1'),
(380, 39, '_user_login', '1p21.admin'),
(381, 39, '_user_email', 'garrett@1pointinteractive.com'),
(382, 39, '_server_remote_addr', '::1'),
(383, 39, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit-tags.php?taxonomy=category'),
(384, 40, 'post_id', '64'),
(385, 40, 'post_type', 'post'),
(386, 40, 'post_title', 'Driving While Distracted? It Could Cost You.'),
(387, 40, '_message_key', 'post_updated'),
(388, 40, '_user_id', '1'),
(389, 40, '_user_login', '1p21.admin'),
(390, 40, '_user_email', 'garrett@1pointinteractive.com'),
(391, 40, '_server_remote_addr', '::1'),
(392, 40, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(393, 41, 'post_id', '62'),
(394, 41, 'post_type', 'post'),
(395, 41, 'post_title', 'Takata Airbag Recall: The Largest Auto Recall in US History'),
(396, 41, '_message_key', 'post_updated'),
(397, 41, '_user_id', '1'),
(398, 41, '_user_login', '1p21.admin'),
(399, 41, '_user_email', 'garrett@1pointinteractive.com'),
(400, 41, '_server_remote_addr', '::1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(401, 41, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(402, 42, 'post_id', '66'),
(403, 42, 'post_type', 'post'),
(404, 42, 'post_title', 'Test Post'),
(405, 42, '_message_key', 'post_created'),
(406, 42, '_user_id', '1'),
(407, 42, '_user_login', '1p21.admin'),
(408, 42, '_user_email', 'garrett@1pointinteractive.com'),
(409, 42, '_server_remote_addr', '::1'),
(410, 42, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php'),
(411, 43, 'post_id', '66'),
(412, 43, 'post_type', 'post'),
(413, 43, 'post_title', 'Test Post'),
(414, 43, 'post_prev_post_name', ''),
(415, 43, 'post_new_post_name', 'test-post'),
(416, 43, 'post_prev_post_content', ''),
(417, 43, 'post_new_post_content', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(418, 43, 'post_prev_post_status', 'draft'),
(419, 43, 'post_new_post_status', 'publish'),
(420, 43, 'post_prev_post_date', '2018-06-05 02:52:51'),
(421, 43, 'post_new_post_date', '2018-06-05 02:53:09'),
(422, 43, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(423, 43, 'post_new_post_date_gmt', '2018-06-05 02:53:09'),
(424, 43, '_message_key', 'post_updated'),
(425, 43, '_user_id', '1'),
(426, 43, '_user_login', '1p21.admin'),
(427, 43, '_user_email', 'garrett@1pointinteractive.com'),
(428, 43, '_server_remote_addr', '::1'),
(429, 43, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?wp-post-new-reload=true&wp-post-new-reload=true'),
(430, 44, 'post_id', '68'),
(431, 44, 'post_type', 'post'),
(432, 44, 'post_title', 'Test Post  Copy'),
(433, 44, '_message_key', 'post_updated'),
(434, 44, '_user_id', '1'),
(435, 44, '_user_login', '1p21.admin'),
(436, 44, '_user_email', 'garrett@1pointinteractive.com'),
(437, 44, '_server_remote_addr', '::1'),
(438, 44, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(439, 45, 'post_id', '69'),
(440, 45, 'post_type', 'post'),
(441, 45, 'post_title', 'Test Post  Copy  Copy'),
(442, 45, '_message_key', 'post_updated'),
(443, 45, '_user_id', '1'),
(444, 45, '_user_login', '1p21.admin'),
(445, 45, '_user_email', 'garrett@1pointinteractive.com'),
(446, 45, '_server_remote_addr', '::1'),
(447, 45, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php?post-duplicated=68'),
(448, 46, 'post_id', '70'),
(449, 46, 'post_type', 'post'),
(450, 46, 'post_title', 'Test Post  Copy  Copy  Copy'),
(451, 46, '_message_key', 'post_updated'),
(452, 46, '_user_id', '1'),
(453, 46, '_user_login', '1p21.admin'),
(454, 46, '_user_email', 'garrett@1pointinteractive.com'),
(455, 46, '_server_remote_addr', '::1'),
(456, 46, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php?post-duplicated=69'),
(457, 47, 'menu_id', '2'),
(458, 47, 'menu_name', 'Menu 1'),
(459, 47, 'menu_items_added', '1'),
(460, 47, 'menu_items_removed', '0'),
(461, 47, '_message_key', 'edited_menu'),
(462, 47, '_user_id', '1'),
(463, 47, '_user_login', '1p21.admin'),
(464, 47, '_user_email', 'garrett@1pointinteractive.com'),
(465, 47, '_server_remote_addr', '::1'),
(466, 47, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=2'),
(467, 48, 'term_id', '2'),
(468, 48, 'from_term_name', 'Menu 1'),
(469, 48, 'from_term_taxonomy', 'nav_menu'),
(470, 48, 'from_term_slug', 'menu-1'),
(471, 48, 'from_term_description', ''),
(472, 48, 'to_term_name', 'Menu 1'),
(473, 48, 'to_term_taxonomy', 'nav_menu'),
(474, 48, 'to_term_slug', 'null'),
(475, 48, 'to_term_description', ''),
(476, 48, '_message_key', 'edited_term'),
(477, 48, '_user_id', '1'),
(478, 48, '_user_login', '1p21.admin'),
(479, 48, '_user_email', 'garrett@1pointinteractive.com'),
(480, 48, '_server_remote_addr', '::1'),
(481, 48, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=2'),
(482, 49, 'post_id', '70'),
(483, 49, 'post_type', 'post'),
(484, 49, 'post_title', 'Test Post  Copy  Copy  Copy'),
(485, 49, '_message_key', 'post_updated'),
(486, 49, '_user_id', '1'),
(487, 49, '_user_login', '1p21.admin'),
(488, 49, '_user_email', 'garrett@1pointinteractive.com'),
(489, 49, '_server_remote_addr', '::1'),
(490, 49, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(491, 50, 'post_id', '64'),
(492, 50, 'post_type', 'post'),
(493, 50, 'post_title', 'Driving While Distracted? It Could Cost You.'),
(494, 50, '_message_key', 'post_updated'),
(495, 50, '_user_id', '1'),
(496, 50, '_user_login', '1p21.admin'),
(497, 50, '_user_email', 'garrett@1pointinteractive.com'),
(498, 50, '_server_remote_addr', '::1'),
(499, 50, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(500, 51, 'post_id', '64') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(501, 51, 'post_type', 'post'),
(502, 51, 'post_title', 'Driving While Distracted? It Could Cost You.'),
(503, 51, '_message_key', 'post_updated'),
(504, 51, '_user_id', '1'),
(505, 51, '_user_login', '1p21.admin'),
(506, 51, '_user_email', 'garrett@1pointinteractive.com'),
(507, 51, '_server_remote_addr', '::1'),
(508, 51, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php'),
(509, 52, 'widget_id_base', 'search'),
(510, 52, 'widget_name_translated', 'Search'),
(511, 52, 'sidebar_id', 'sidebar'),
(512, 52, 'sidebar_name_translated', 'Recent Posts'),
(513, 52, '_message_key', 'widget_removed'),
(514, 52, '_user_id', '1'),
(515, 52, '_user_login', '1p21.admin'),
(516, 52, '_user_email', 'garrett@1pointinteractive.com'),
(517, 52, '_server_remote_addr', '::1'),
(518, 52, '_server_http_referer', 'http://riddle-demo.com/wp-admin/widgets.php'),
(519, 53, 'widget_id_base', 'recent-comments'),
(520, 53, 'widget_name_translated', 'Recent Comments'),
(521, 53, 'sidebar_id', 'sidebar'),
(522, 53, 'sidebar_name_translated', 'Recent Posts'),
(523, 53, '_message_key', 'widget_removed'),
(524, 53, '_user_id', '1'),
(525, 53, '_user_login', '1p21.admin'),
(526, 53, '_user_email', 'garrett@1pointinteractive.com'),
(527, 53, '_server_remote_addr', '::1'),
(528, 53, '_server_http_referer', 'http://riddle-demo.com/wp-admin/widgets.php'),
(529, 54, 'widget_id_base', 'meta'),
(530, 54, 'widget_name_translated', 'Meta'),
(531, 54, 'sidebar_id', 'sidebar'),
(532, 54, 'sidebar_name_translated', 'Recent Posts'),
(533, 54, '_message_key', 'widget_removed'),
(534, 54, '_user_id', '1'),
(535, 54, '_user_login', '1p21.admin'),
(536, 54, '_user_email', 'garrett@1pointinteractive.com'),
(537, 54, '_server_remote_addr', '::1'),
(538, 54, '_server_http_referer', 'http://riddle-demo.com/wp-admin/widgets.php'),
(539, 55, 'menu_id', '3'),
(540, 55, 'menu_name', 'Practice Areas'),
(541, 55, 'menu_items_added', '1'),
(542, 55, 'menu_items_removed', '0'),
(543, 55, '_message_key', 'edited_menu'),
(544, 55, '_user_id', '1'),
(545, 55, '_user_login', '1p21.admin'),
(546, 55, '_user_email', 'garrett@1pointinteractive.com'),
(547, 55, '_server_remote_addr', '::1'),
(548, 55, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=3'),
(549, 56, 'term_id', '3'),
(550, 56, 'from_term_name', 'Practice Areas'),
(551, 56, 'from_term_taxonomy', 'nav_menu'),
(552, 56, 'from_term_slug', 'practice-areas'),
(553, 56, 'from_term_description', ''),
(554, 56, 'to_term_name', 'Practice Areas'),
(555, 56, 'to_term_taxonomy', 'nav_menu'),
(556, 56, 'to_term_slug', 'null'),
(557, 56, 'to_term_description', ''),
(558, 56, '_message_key', 'edited_term'),
(559, 56, '_user_id', '1'),
(560, 56, '_user_login', '1p21.admin'),
(561, 56, '_user_email', 'garrett@1pointinteractive.com'),
(562, 56, '_server_remote_addr', '::1'),
(563, 56, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=3'),
(564, 57, 'widget_id_base', 'archives'),
(565, 57, 'widget_name_translated', 'Archives'),
(566, 57, 'sidebar_id', 'archive_sidebar'),
(567, 57, 'sidebar_name_translated', 'Archive'),
(568, 57, 'old_instance', '{"title":"","count":0,"dropdown":0}'),
(569, 57, 'new_instance', '{"title":"Archive"}'),
(570, 57, '_message_key', 'widget_edited'),
(571, 57, '_user_id', '1'),
(572, 57, '_user_login', '1p21.admin'),
(573, 57, '_user_email', 'garrett@1pointinteractive.com'),
(574, 57, '_server_remote_addr', '::1'),
(575, 57, '_server_http_referer', 'http://riddle-demo.com/wp-admin/widgets.php'),
(576, 58, 'widget_id_base', 'recent-posts'),
(577, 58, 'widget_name_translated', 'Recent Posts'),
(578, 58, 'sidebar_id', 'sidebar'),
(579, 58, 'sidebar_name_translated', 'Recent Posts'),
(580, 58, 'old_instance', '{"title":"","number":5}'),
(581, 58, 'new_instance', '{"title":"Recent Articles","number":"5"}'),
(582, 58, '_message_key', 'widget_edited'),
(583, 58, '_user_id', '1'),
(584, 58, '_user_login', '1p21.admin'),
(585, 58, '_user_email', 'garrett@1pointinteractive.com'),
(586, 58, '_server_remote_addr', '::1'),
(587, 58, '_server_http_referer', 'http://riddle-demo.com/wp-admin/widgets.php'),
(588, 59, 'plugin_name', 'Yoast SEO'),
(589, 59, 'plugin_current_version', '7.4.2'),
(590, 59, 'plugin_new_version', '7.6'),
(591, 59, '_message_key', 'plugin_update_available'),
(592, 59, '_server_remote_addr', '::1'),
(593, 59, '_server_http_referer', 'http://riddle-demo.com/wp-cron.php?doing_wp_cron=1528212124.4354588985443115234375'),
(594, 60, 'plugin_name', 'Yoast SEO'),
(595, 60, 'plugin_current_version', '7.4.2'),
(596, 60, 'plugin_new_version', '7.6'),
(597, 60, '_message_key', 'plugin_update_available'),
(598, 60, '_user_id', '1'),
(599, 60, '_user_login', '1p21.admin'),
(600, 60, '_user_email', 'garrett@1pointinteractive.com') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(601, 60, '_server_remote_addr', '::1'),
(602, 60, '_server_http_referer', 'http://riddle-demo.com/wp-admin/admin.php?page=gf_edit_forms&view=settings&subview=confirmation&id=2'),
(603, 61, '_message_key', 'user_logged_out'),
(604, 61, '_user_id', '1'),
(605, 61, '_user_login', '1p21.admin'),
(606, 61, '_user_email', 'garrett@1pointinteractive.com'),
(607, 61, '_server_remote_addr', '::1'),
(608, 61, '_server_http_referer', 'http://riddle-demo.com/practice-area/'),
(609, 62, 'user_id', '1'),
(610, 62, 'user_email', 'garrett@1pointinteractive.com'),
(611, 62, 'user_login', '1p21.admin'),
(612, 62, '_user_id', '1'),
(613, 62, '_user_login', '1p21.admin'),
(614, 62, '_user_email', 'garrett@1pointinteractive.com'),
(615, 62, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'),
(616, 62, '_message_key', 'user_logged_in'),
(617, 62, '_server_remote_addr', '::1'),
(618, 62, '_server_http_referer', 'http://riddle-demo.com/wp-login.php?redirect_to=http%3A%2F%2Friddle-demo.com%2Fwp-admin%2Fpost-new.php%3Fpost_type%3Dpage&reauth=1'),
(619, 63, 'plugin_slug', 'akismet'),
(620, 63, 'plugin_name', 'Akismet Anti-Spam'),
(621, 63, 'plugin_title', '<a href="https://akismet.com/">Akismet Anti-Spam</a>'),
(622, 63, 'plugin_description', 'Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key. <cite>By <a href="https://automattic.com/wordpress-plugins/">Automattic</a>.</cite>'),
(623, 63, 'plugin_author', '<a href="https://automattic.com/wordpress-plugins/">Automattic</a>'),
(624, 63, 'plugin_version', '4.0.7'),
(625, 63, 'plugin_url', 'https://akismet.com/'),
(626, 63, 'plugin_prev_version', '4.0.3'),
(627, 63, '_message_key', 'plugin_bulk_updated'),
(628, 63, '_user_id', '1'),
(629, 63, '_user_login', '1p21.admin'),
(630, 63, '_user_email', 'garrett@1pointinteractive.com'),
(631, 63, '_server_remote_addr', '::1'),
(632, 63, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(633, 64, 'plugin_slug', 'gravityforms'),
(634, 64, 'plugin_name', 'Gravity Forms'),
(635, 64, 'plugin_title', '<a href="https://www.gravityforms.com">Gravity Forms</a>'),
(636, 64, 'plugin_description', 'Easily create web forms and manage form entries within the WordPress admin. <cite>By <a href="https://www.rocketgenius.com">rocketgenius</a>.</cite>'),
(637, 64, 'plugin_author', '<a href="https://www.rocketgenius.com">rocketgenius</a>'),
(638, 64, 'plugin_version', '2.3.2'),
(639, 64, 'plugin_url', 'https://www.gravityforms.com'),
(640, 64, 'plugin_update_info_plugin', 'gravityforms/gravityforms.php'),
(641, 64, 'plugin_update_info_package', 'http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1528384928&Signature=6Gw9F4GzdYg%2BQkc6RFdYryJ85cY%3D'),
(642, 64, 'plugin_prev_version', '2.3.1'),
(643, 64, '_message_key', 'plugin_bulk_updated'),
(644, 64, '_user_id', '1'),
(645, 64, '_user_login', '1p21.admin'),
(646, 64, '_user_email', 'garrett@1pointinteractive.com'),
(647, 64, '_server_remote_addr', '::1'),
(648, 64, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(649, 65, 'plugin_slug', 'better-wp-security'),
(650, 65, 'plugin_name', 'iThemes Security'),
(651, 65, 'plugin_title', '<a href="https://ithemes.com/security">iThemes Security</a>'),
(652, 65, 'plugin_description', 'Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin. <cite>By <a href="https://ithemes.com">iThemes</a>.</cite>'),
(653, 65, 'plugin_author', '<a href="https://ithemes.com">iThemes</a>'),
(654, 65, 'plugin_version', '7.0.1'),
(655, 65, 'plugin_url', 'https://ithemes.com/security'),
(656, 65, 'plugin_prev_version', '6.9.2'),
(657, 65, '_message_key', 'plugin_bulk_updated'),
(658, 65, '_user_id', '1'),
(659, 65, '_user_login', '1p21.admin'),
(660, 65, '_user_email', 'garrett@1pointinteractive.com'),
(661, 65, '_server_remote_addr', '::1'),
(662, 65, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(663, 66, 'plugin_slug', 'mailgun'),
(664, 66, 'plugin_name', 'Mailgun'),
(665, 66, 'plugin_title', '<a href="http://wordpress.org/extend/plugins/mailgun/">Mailgun</a>'),
(666, 66, 'plugin_description', 'Mailgun integration for WordPress <cite>By <a href="http://www.mailgun.com/">Mailgun</a>.</cite>'),
(667, 66, 'plugin_author', '<a href="http://www.mailgun.com/">Mailgun</a>'),
(668, 66, 'plugin_version', '1.5.11'),
(669, 66, 'plugin_url', 'http://wordpress.org/extend/plugins/mailgun/'),
(670, 66, 'plugin_prev_version', '1.5.8.5'),
(671, 66, '_message_key', 'plugin_bulk_updated'),
(672, 66, '_user_id', '1'),
(673, 66, '_user_login', '1p21.admin'),
(674, 66, '_user_email', 'garrett@1pointinteractive.com'),
(675, 66, '_server_remote_addr', '::1'),
(676, 66, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(677, 67, 'plugin_slug', 'simple-history'),
(678, 67, 'plugin_name', 'Simple History'),
(679, 67, 'plugin_title', '<a href="http://simple-history.com">Simple History</a>'),
(680, 67, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI. <cite>By <a href="http://simple-history.com/">Pär Thernström</a>.</cite>'),
(681, 67, 'plugin_author', '<a href="http://simple-history.com/">Pär Thernström</a>'),
(682, 67, 'plugin_version', '2.23.1'),
(683, 67, 'plugin_url', 'http://simple-history.com'),
(684, 67, 'plugin_prev_version', '2.20'),
(685, 67, '_message_key', 'plugin_bulk_updated'),
(686, 67, '_user_id', '1'),
(687, 67, '_user_login', '1p21.admin'),
(688, 67, '_user_email', 'garrett@1pointinteractive.com'),
(689, 67, '_server_remote_addr', '::1'),
(690, 67, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(691, 68, 'plugin_slug', 'wp-super-cache'),
(692, 68, 'plugin_name', 'WP Super Cache'),
(693, 68, 'plugin_title', '<a href="https://wordpress.org/plugins/wp-super-cache/">WP Super Cache</a>'),
(694, 68, 'plugin_description', 'Very fast caching plugin for WordPress. <cite>By <a href="https://automattic.com/">Automattic</a>.</cite>'),
(695, 68, 'plugin_author', '<a href="https://automattic.com/">Automattic</a>'),
(696, 68, 'plugin_version', '1.6.1'),
(697, 68, 'plugin_url', 'https://wordpress.org/plugins/wp-super-cache/'),
(698, 68, 'plugin_prev_version', '1.6.0'),
(699, 68, '_message_key', 'plugin_bulk_updated'),
(700, 68, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(701, 68, '_user_login', '1p21.admin'),
(702, 68, '_user_email', 'garrett@1pointinteractive.com'),
(703, 68, '_server_remote_addr', '::'),
(704, 68, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(705, 69, 'plugin_slug', 'wordpress-seo'),
(706, 69, 'plugin_name', 'Yoast SEO'),
(707, 69, 'plugin_title', '<a href="https://yoa.st/1uj">Yoast SEO</a>'),
(708, 69, 'plugin_description', 'The first true all-in-one SEO solution for WordPress, including on-page content analysis, XML sitemaps and much more. <cite>By <a href="https://yoa.st/1uk">Team Yoast</a>.</cite>'),
(709, 69, 'plugin_author', '<a href="https://yoa.st/1uk">Team Yoast</a>'),
(710, 69, 'plugin_version', '7.6'),
(711, 69, 'plugin_url', 'https://yoa.st/1uj'),
(712, 69, 'plugin_prev_version', '7.4.2'),
(713, 69, '_message_key', 'plugin_bulk_updated'),
(714, 69, '_user_id', '1'),
(715, 69, '_user_login', '1p21.admin'),
(716, 69, '_user_email', 'garrett@1pointinteractive.com'),
(717, 69, '_server_remote_addr', '::'),
(718, 69, '_server_http_referer', 'http://riddle-demo.com/wp-admin/plugins.php'),
(719, 70, 'post_id', '76'),
(720, 70, 'post_type', 'acf-field-group'),
(721, 70, 'post_title', 'Blog'),
(722, 70, '_message_key', 'post_created'),
(723, 70, '_user_id', '1'),
(724, 70, '_user_login', '1p21.admin'),
(725, 70, '_user_email', 'garrett@1pointinteractive.com'),
(726, 70, '_server_remote_addr', '::'),
(727, 70, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(728, 71, 'post_type', 'attachment'),
(729, 71, 'attachment_id', '78'),
(730, 71, 'attachment_title', 'intl_blog_img'),
(731, 71, 'attachment_filename', 'intl_blog_img.jpg'),
(732, 71, 'attachment_mime', 'image/jpeg'),
(733, 71, 'attachment_filesize', '20682'),
(734, 71, '_message_key', 'attachment_created'),
(735, 71, '_user_id', '1'),
(736, 71, '_user_login', '1p21.admin'),
(737, 71, '_user_email', 'garrett@1pointinteractive.com'),
(738, 71, '_server_remote_addr', '::'),
(739, 71, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=70&action=edit'),
(740, 72, 'post_id', '70'),
(741, 72, 'post_type', 'post'),
(742, 72, 'post_title', 'Test Post  Copy  Copy  Copy'),
(743, 72, '_message_key', 'post_updated'),
(744, 72, '_user_id', '1'),
(745, 72, '_user_login', '1p21.admin'),
(746, 72, '_user_email', 'garrett@1pointinteractive.com'),
(747, 72, '_server_remote_addr', '::'),
(748, 72, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=70&action=edit'),
(749, 72, 'acf_field_added_0/slug', 'featured_image'),
(750, 72, 'acf_field_added_0/key', 'field_5b16be6abe7f9'),
(751, 72, 'acf_field_added_0/label', 'Featured Image'),
(752, 72, 'acf_field_added_0/type', 'image'),
(753, 72, 'acf_field_added_0/path_0/name', 'Blog'),
(754, 72, 'acf_field_added_0/path_0/type', 'field_group'),
(755, 73, 'post_id', '70'),
(756, 73, 'post_type', 'post'),
(757, 73, 'post_title', 'Test Post  Copy  Copy  Copy'),
(758, 73, '_message_key', 'post_updated'),
(759, 73, '_user_id', '1'),
(760, 73, '_user_login', '1p21.admin'),
(761, 73, '_user_email', 'garrett@1pointinteractive.com'),
(762, 73, '_server_remote_addr', '::'),
(763, 73, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=70&action=edit'),
(764, 74, 'post_id', '13'),
(765, 74, 'post_type', 'page'),
(766, 74, 'post_title', 'Practice Area'),
(767, 74, 'post_prev_post_content', ''),
(768, 74, 'post_new_post_content', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n			\r\n			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<h2>H2 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</h2>\r\n\r\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas <a href="">embedded link </a> aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\r\n\r\n\r\n<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</blockquote>\r\n\r\n<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur:</p>\r\n\r\n<ul>\r\n	<li>Excepteur sint occ Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.aecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</li>\r\n	<li>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium</li>\r\n	<li>am rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</li> \r\n</ul>\r\n<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p> \r\n\r\n<h3>H3 Lorem ipsum dolor sit amet, consectetur ad</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n'),
(769, 74, '_message_key', 'post_updated'),
(770, 74, '_user_id', '1'),
(771, 74, '_user_login', '1p21.admin'),
(772, 74, '_user_email', 'garrett@1pointinteractive.com'),
(773, 74, '_server_remote_addr', '::'),
(774, 74, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=13&action=edit'),
(775, 75, 'post_id', '81'),
(776, 75, 'post_type', 'page'),
(777, 75, 'post_title', 'Gene Riddle'),
(778, 75, '_message_key', 'post_created'),
(779, 75, '_user_id', '1'),
(780, 75, '_user_login', '1p21.admin'),
(781, 75, '_user_email', 'garrett@1pointinteractive.com'),
(782, 75, '_server_remote_addr', '::'),
(783, 75, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page'),
(784, 76, 'post_id', '81'),
(785, 76, 'post_type', 'page'),
(786, 76, 'post_title', 'Gene Riddle'),
(787, 76, 'post_prev_post_name', ''),
(788, 76, 'post_new_post_name', 'gene-riddle'),
(789, 76, 'post_prev_post_status', 'draft'),
(790, 76, 'post_new_post_status', 'publish'),
(791, 76, 'post_prev_post_date', '2018-06-05 17:49:18'),
(792, 76, 'post_new_post_date', '2018-06-05 17:49:30'),
(793, 76, 'post_prev_post_date_gmt', '0000-00-00 00:00:00'),
(794, 76, 'post_new_post_date_gmt', '2018-06-05 17:49:30'),
(795, 76, '_message_key', 'post_updated'),
(796, 76, '_user_id', '1'),
(797, 76, '_user_login', '1p21.admin'),
(798, 76, '_user_email', 'garrett@1pointinteractive.com'),
(799, 76, '_server_remote_addr', '::'),
(800, 76, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(801, 77, 'post_id', '81'),
(802, 77, 'post_type', 'page'),
(803, 77, 'post_title', 'Gene Riddle'),
(804, 77, 'post_prev_page_template', 'default'),
(805, 77, 'post_new_page_template', 'page-profile.php'),
(806, 77, 'post_new_page_template_name', 'Att Bio'),
(807, 77, '_message_key', 'post_updated'),
(808, 77, '_user_id', '1'),
(809, 77, '_user_login', '1p21.admin'),
(810, 77, '_user_email', 'garrett@1pointinteractive.com'),
(811, 77, '_server_remote_addr', '::'),
(812, 77, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(813, 78, 'menu_id', '2'),
(814, 78, 'menu_name', 'Menu 1'),
(815, 78, 'menu_items_added', '1'),
(816, 78, 'menu_items_removed', '0'),
(817, 78, '_message_key', 'edited_menu'),
(818, 78, '_user_id', '1'),
(819, 78, '_user_login', '1p21.admin'),
(820, 78, '_user_email', 'garrett@1pointinteractive.com'),
(821, 78, '_server_remote_addr', '::'),
(822, 78, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=2'),
(823, 79, 'term_id', '2'),
(824, 79, 'from_term_name', 'Menu 1'),
(825, 79, 'from_term_taxonomy', 'nav_menu'),
(826, 79, 'from_term_slug', 'menu-1'),
(827, 79, 'from_term_description', ''),
(828, 79, 'to_term_name', 'Menu 1'),
(829, 79, 'to_term_taxonomy', 'nav_menu'),
(830, 79, 'to_term_slug', 'null'),
(831, 79, 'to_term_description', ''),
(832, 79, '_message_key', 'edited_term'),
(833, 79, '_user_id', '1'),
(834, 79, '_user_login', '1p21.admin'),
(835, 79, '_user_email', 'garrett@1pointinteractive.com'),
(836, 79, '_server_remote_addr', '::'),
(837, 79, '_server_http_referer', 'http://riddle-demo.com/wp-admin/nav-menus.php?action=edit&menu=2'),
(838, 80, '_message_key', 'user_logged_out'),
(839, 80, '_user_id', '1'),
(840, 80, '_user_login', '1p21.admin'),
(841, 80, '_user_email', 'garrett@1pointinteractive.com'),
(842, 80, '_server_remote_addr', '::'),
(843, 80, '_server_http_referer', 'http://riddle-demo.com/'),
(844, 81, 'user_id', '1'),
(845, 81, 'user_email', 'garrett@1pointinteractive.com'),
(846, 81, 'user_login', '1p21.admin'),
(847, 81, '_user_id', '1'),
(848, 81, '_user_login', '1p21.admin'),
(849, 81, '_user_email', 'garrett@1pointinteractive.com'),
(850, 81, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'),
(851, 81, '_message_key', 'user_logged_in'),
(852, 81, '_server_remote_addr', '::'),
(853, 81, '_server_http_referer', 'http://riddle-demo.com/wp-login.php?interim-login=1&wp_lang=en_US'),
(854, 82, 'post_id', '84'),
(855, 82, 'post_type', 'acf-field-group'),
(856, 82, 'post_title', 'Attorney Bio'),
(857, 82, '_message_key', 'post_created'),
(858, 82, '_user_id', '1'),
(859, 82, '_user_login', '1p21.admin'),
(860, 82, '_user_email', 'garrett@1pointinteractive.com'),
(861, 82, '_server_remote_addr', '::'),
(862, 82, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post-new.php?post_type=acf-field-group&wp-post-new-reload=true'),
(863, 83, 'post_id', '81'),
(864, 83, 'post_type', 'page'),
(865, 83, 'post_title', 'Gene Riddle'),
(866, 83, '_message_key', 'post_updated'),
(867, 83, '_user_id', '1'),
(868, 83, '_user_login', '1p21.admin'),
(869, 83, '_user_email', 'garrett@1pointinteractive.com'),
(870, 83, '_server_remote_addr', '::'),
(871, 83, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(872, 83, 'acf_field_added_0/slug', 'attorney_first_name'),
(873, 83, 'acf_field_added_0/key', 'field_5b1700a8d4ae8'),
(874, 83, 'acf_field_added_0/label', 'Attorney First Name'),
(875, 83, 'acf_field_added_0/type', 'text'),
(876, 83, 'acf_field_added_0/path_0/name', 'Attorney Bio'),
(877, 83, 'acf_field_added_0/path_0/type', 'field_group'),
(878, 83, 'acf_field_added_1/slug', 'attorney_last_name'),
(879, 83, 'acf_field_added_1/key', 'field_5b1700b2d4ae9'),
(880, 83, 'acf_field_added_1/label', 'Attorney Last Name'),
(881, 83, 'acf_field_added_1/type', 'text'),
(882, 83, 'acf_field_added_1/path_0/name', 'Attorney Bio'),
(883, 83, 'acf_field_added_1/path_0/type', 'field_group'),
(884, 84, 'post_id', '84'),
(885, 84, 'post_type', 'acf-field-group'),
(886, 84, 'post_title', 'Attorney Bio'),
(887, 84, 'acf_added_fields_0_key', 'field_5b1701294cd6d'),
(888, 84, 'acf_added_fields_0_name', 'attorney_position'),
(889, 84, 'acf_added_fields_0_label', 'Attorney Position'),
(890, 84, 'acf_added_fields_0_type', 'text'),
(891, 84, '_message_key', 'post_updated'),
(892, 84, '_user_id', '1'),
(893, 84, '_user_login', '1p21.admin'),
(894, 84, '_user_email', 'garrett@1pointinteractive.com'),
(895, 84, '_server_remote_addr', '::'),
(896, 84, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=84&action=edit'),
(897, 85, 'post_id', '81'),
(898, 85, 'post_type', 'page'),
(899, 85, 'post_title', 'Gene Riddle'),
(900, 85, '_message_key', 'post_updated') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(901, 85, '_user_id', '1'),
(902, 85, '_user_login', '1p21.admin'),
(903, 85, '_user_email', 'garrett@1pointinteractive.com'),
(904, 85, '_server_remote_addr', '::'),
(905, 85, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(906, 85, 'acf_field_added_0/slug', 'attorney_position'),
(907, 85, 'acf_field_added_0/key', 'field_5b1701294cd6d'),
(908, 85, 'acf_field_added_0/label', 'Attorney Position'),
(909, 85, 'acf_field_added_0/type', 'text'),
(910, 85, 'acf_field_added_0/path_0/name', 'Attorney Bio'),
(911, 85, 'acf_field_added_0/path_0/type', 'field_group'),
(912, 86, 'post_id', '84'),
(913, 86, 'post_type', 'acf-field-group'),
(914, 86, 'post_title', 'Attorney Bio'),
(915, 86, 'acf_added_fields_0_key', 'field_5b17015119026'),
(916, 86, 'acf_added_fields_0_name', 'attorney_image'),
(917, 86, 'acf_added_fields_0_label', 'Attorney Image'),
(918, 86, 'acf_added_fields_0_type', 'image'),
(919, 86, '_message_key', 'post_updated'),
(920, 86, '_user_id', '1'),
(921, 86, '_user_login', '1p21.admin'),
(922, 86, '_user_email', 'garrett@1pointinteractive.com'),
(923, 86, '_server_remote_addr', '::'),
(924, 86, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=84&action=edit'),
(925, 87, 'post_id', '84'),
(926, 87, 'post_type', 'acf-field-group'),
(927, 87, 'post_title', 'Attorney Bio'),
(928, 87, 'acf_modified_fields_0_ID_prev', '90'),
(929, 87, 'acf_modified_fields_0_name_prev', 'attorney_image'),
(930, 87, 'acf_modified_fields_0_label_prev', 'Attorney Image'),
(931, 87, '_message_key', 'post_updated'),
(932, 87, '_user_id', '1'),
(933, 87, '_user_login', '1p21.admin'),
(934, 87, '_user_email', 'garrett@1pointinteractive.com'),
(935, 87, '_server_remote_addr', '::'),
(936, 87, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=84&action=edit'),
(937, 88, 'post_type', 'attachment'),
(938, 88, 'attachment_id', '91'),
(939, 88, 'attachment_title', 'att'),
(940, 88, 'attachment_filename', 'att.jpg'),
(941, 88, 'attachment_mime', 'image/jpeg'),
(942, 88, 'attachment_filesize', '35556'),
(943, 88, '_message_key', 'attachment_created'),
(944, 88, '_user_id', '1'),
(945, 88, '_user_login', '1p21.admin'),
(946, 88, '_user_email', 'garrett@1pointinteractive.com'),
(947, 88, '_server_remote_addr', '::'),
(948, 88, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(949, 89, 'post_id', '81'),
(950, 89, 'post_type', 'page'),
(951, 89, 'post_title', 'Gene Riddle'),
(952, 89, '_message_key', 'post_updated'),
(953, 89, '_user_id', '1'),
(954, 89, '_user_login', '1p21.admin'),
(955, 89, '_user_email', 'garrett@1pointinteractive.com'),
(956, 89, '_server_remote_addr', '::'),
(957, 89, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(958, 89, 'acf_field_added_0/slug', 'attorney_image'),
(959, 89, 'acf_field_added_0/key', 'field_5b17015119026'),
(960, 89, 'acf_field_added_0/label', 'Attorney Image'),
(961, 89, 'acf_field_added_0/type', 'image'),
(962, 89, 'acf_field_added_0/path_0/name', 'Attorney Bio'),
(963, 89, 'acf_field_added_0/path_0/type', 'field_group'),
(964, 89, 'acf_field_changed_0/slug', 'attorney_position'),
(965, 89, 'acf_field_changed_0/key', 'field_5b1701294cd6d'),
(966, 89, 'acf_field_changed_0/label', 'Attorney Position'),
(967, 89, 'acf_field_changed_0/type', 'text'),
(968, 89, 'acf_field_changed_0/path_0/name', 'Attorney Bio'),
(969, 89, 'acf_field_changed_0/path_0/type', 'field_group'),
(970, 90, 'post_id', '81'),
(971, 90, 'post_type', 'page'),
(972, 90, 'post_title', 'Gene Riddle'),
(973, 90, 'post_prev_post_content', ''),
(974, 90, 'post_new_post_content', 'Gene Riddle is a founding member of Riddle &amp; Brantley, LLP, a law firm that employs 10 lawyers with more than 160 years of combined legal experience. Gene is quick to stress his family’s deep North Carolina ties. A Stanly County native, he grew up in Aberdeen after moving from Albemarle. He has practiced law in North Carolina since September 1985. Gene’s parents were both educators. His father, a longtime superintendent of Moore County Schools, encouraged him to go to law school after college.\r\n<blockquote>“My dad is probably the most honest person that was ever born,” he says. “Honest to a fault. He said we needed more honest lawyers, and I’d be a good one.”</blockquote>\r\nToday, Gene believes honesty, integrity and willingness to work hard are the bedrock principles of a good attorney. That is what he and the other lawyers at Riddle &amp; Brantley, LLP provide to their injured clients. Gene spends much of his time reviewing cases as well as instructing and supervising attorneys and paralegals. However, he also continues to directly handle cases as the lead attorney and he touches most of the personal injury cases that come into the firm.\r\n<h2>North Carolina Personal Injury Lawyer Committed to 24/7 Client Service</h2>\r\nGene is particularly proud of his firm’s pledge to respond to phone calls and e-mails 24/7. As a result, he monitors almost all inquiries received, even after hours and on weekends. Gene takes on cases that involve serious personal injury in car accidents, truck accidents, dog bites, premises liability, wrongful death and violations of Constitutional Rights. In every case, Gene’s objective is obtaining an outcome that his client believes is fair.\r\n<h2>Attorney with a Reputation for Success in State and Federal Courtrooms</h2>\r\nJustice usually means compensation for the injured party’s losses, including their pain and suffering. Still, according to Gene, in many cases the acknowledgement of the defendant’s fault or even an apology is also valuable.\r\n\r\nIn one case, Gene represented a spectator at a high school basketball game who was badly injured when bleachers he was climbing shifted. The client fell through, severely injuring his leg. The man suffered permanent injury to his leg and incurred $2,500 in medical bills. The bleachers were not pulled out properly and stabilized, leading to the accident, Gene says. However, the school system would not admit any negligence, nor would it consider any settlement. This negligence prompted a courtroom battle where Gene prevailed. In Carter v. Wayne County Board of Education, the jury returned a verdict of $250,000 for the plaintiff.\r\n\r\nGene also represented five women in a claim against a Wayne County sheriff’s deputy. These women alleged the deputy had demanded sex in return for favorable treatment for their pending criminal cases. Four of Gene’s clients settled their lawsuits against the Wayne County Sheriff’s Department and the county. One client proceeded to federal court against the deputy, alleging he had violated her Constitutional protection against cruel and unusual punishment. Gene prevailed for his client in the courtroom.\r\n\r\nIn Fordman v. Braswell, the jury awarded the plaintiff $1.5 million in actual damages and $3.5 million in punitive damages. According to news reports, after the court heard the evidence Gene presented on behalf of the plaintiff, the defense said it would no longer contest the case. Judge Terrence Boyle then dismissed the jury and imposed the judgment.\r\n<h2>Goldsboro Wrongful Death Case: “I Believe I Truly Got Justice”</h2>\r\nOn his desk, Gene keeps a photo of 16-year-old girl, her parents’ only child. The girl died after a tractor-trailer hit her car in an intersection in Goldsboro. The initial investigation of the accident supported the truck driver’s version of the facts. He said he had a green light at the time of the accident. The girl’s devastated parents were not satisfied with the truck driver’s account, so they contacted Riddle &amp; Brantley, LLP. Our investigation revealed a different story.\r\n\r\nInvestigators tracked down eyewitnesses who contradicted the truck driver. Gene then hired accident reconstructionists whose forensic work showed that the truck driver had indeed run a red light. The trucking company’s insurers agreed with the new evidence and settled, paying the grieving parents $840,000. Additionally, the truck driver faced charges for misdemeanor death by motor vehicle. He pled guilty and eventually lost his commercial driver’s license for a year.\r\n<h2>Memberships and Professional Recognition</h2>\r\nGene’s legal accomplishments have earned him several professional honors from his legal peers, including the 2014 Litigator Award. He also has a high AV Rating from Martindale-Hubbell as well as designation among the Best Attorneys of America and the American Trial Lawyers Association’s Top 100 Trial Lawyers. Additionally, he earned membership in the Million Dollar and Multi-Million Dollar Advocates Forums, based on verdicts won and settlements reached.\r\n\r\nHowever, the award Gene treasures most is the Old North State Award, which he received in 2009. The Old North State Award is presented by the North Carolina governor to individuals who have provided exemplary service and commitment to the state. Gene received it for his community service as a member and chairman of the Wayne County Board of Elections over four years.\r\n\r\nWhy does the Old North State Award mean so much to Gene? It is the state’s second-highest award. The state’s highest civilian award is induction by the governor into the Order of the Longleaf Pine in recognition of service to the state. Gene’s father received an Order of the Longleaf Pine Award upon his retirement in 1999.\r\n<h2>Family and Free Time</h2>\r\nGene and his wife have two daughters and several pets, including a Westie named “Coconut” who has been featured in several TV commercials. Church activities'),
(975, 90, '_message_key', 'post_updated'),
(976, 90, '_user_id', '1'),
(977, 90, '_user_login', '1p21.admin'),
(978, 90, '_user_email', 'garrett@1pointinteractive.com'),
(979, 90, '_server_remote_addr', '::'),
(980, 90, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(981, 91, 'post_id', '84'),
(982, 91, 'post_type', 'acf-field-group'),
(983, 91, 'post_title', 'Attorney Bio'),
(984, 91, 'acf_added_fields_0_key', 'field_5b1702508474d'),
(985, 91, 'acf_added_fields_0_name', 'attorney_accolades'),
(986, 91, 'acf_added_fields_0_label', 'Attorney Accolades'),
(987, 91, 'acf_added_fields_0_type', 'repeater'),
(988, 91, 'acf_added_fields_1_key', 'field_5b1702868474e'),
(989, 91, 'acf_added_fields_1_name', 'accolade_header'),
(990, 91, 'acf_added_fields_1_label', 'Accolade Header'),
(991, 91, 'acf_added_fields_1_type', 'text'),
(992, 91, 'acf_added_fields_2_key', 'field_5b1702918474f'),
(993, 91, 'acf_added_fields_2_name', 'accolade_list'),
(994, 91, 'acf_added_fields_2_label', 'Accolade List'),
(995, 91, 'acf_added_fields_2_type', 'repeater'),
(996, 91, 'acf_added_fields_3_key', 'field_5b1702a484750'),
(997, 91, 'acf_added_fields_3_name', 'single_bullet'),
(998, 91, 'acf_added_fields_3_label', 'Single Bullet'),
(999, 91, 'acf_added_fields_3_type', 'text'),
(1000, 91, '_message_key', 'post_updated') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1001, 91, '_user_id', '1'),
(1002, 91, '_user_login', '1p21.admin'),
(1003, 91, '_user_email', 'garrett@1pointinteractive.com'),
(1004, 91, '_server_remote_addr', '::'),
(1005, 91, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=84&action=edit'),
(1006, 92, 'post_id', '81'),
(1007, 92, 'post_type', 'page'),
(1008, 92, 'post_title', 'Gene Riddle'),
(1009, 92, '_message_key', 'post_updated'),
(1010, 92, '_user_id', '1'),
(1011, 92, '_user_login', '1p21.admin'),
(1012, 92, '_user_email', 'garrett@1pointinteractive.com'),
(1013, 92, '_server_remote_addr', '::'),
(1014, 92, '_server_http_referer', 'http://riddle-demo.com/wp-admin/post.php?post=81&action=edit'),
(1015, 92, 'acf_field_added_0/slug', 'attorney_accolades_0_accolade_header'),
(1016, 92, 'acf_field_added_0/key', 'field_5b1702868474e'),
(1017, 92, 'acf_field_added_0/label', 'Accolade Header'),
(1018, 92, 'acf_field_added_0/type', 'text'),
(1019, 92, 'acf_field_added_0/path_0/name', 'Attorney Bio'),
(1020, 92, 'acf_field_added_0/path_0/type', 'field_group'),
(1021, 92, 'acf_field_added_0/path_1/name', 'Attorney Accolades'),
(1022, 92, 'acf_field_added_0/path_1/type', 'field'),
(1023, 92, 'acf_field_added_0/path_1/field_type', 'repeater'),
(1024, 92, 'acf_field_added_1/slug', 'attorney_accolades_0_accolade_list_0_single_bullet'),
(1025, 92, 'acf_field_added_1/key', 'field_5b1702a484750'),
(1026, 92, 'acf_field_added_1/label', 'Single Bullet'),
(1027, 92, 'acf_field_added_1/type', 'text'),
(1028, 92, 'acf_field_added_1/path_0/name', 'Attorney Bio'),
(1029, 92, 'acf_field_added_1/path_0/type', 'field_group'),
(1030, 92, 'acf_field_added_1/path_1/name', 'Attorney Accolades'),
(1031, 92, 'acf_field_added_1/path_1/type', 'field'),
(1032, 92, 'acf_field_added_1/path_1/field_type', 'repeater'),
(1033, 92, 'acf_field_added_1/path_2/name', 'Accolade List'),
(1034, 92, 'acf_field_added_1/path_2/type', 'field'),
(1035, 92, 'acf_field_added_1/path_2/field_type', 'repeater'),
(1036, 92, 'acf_field_added_2/slug', 'attorney_accolades_0_accolade_list_1_single_bullet'),
(1037, 92, 'acf_field_added_2/key', 'field_5b1702a484750'),
(1038, 92, 'acf_field_added_2/label', 'Single Bullet'),
(1039, 92, 'acf_field_added_2/type', 'text'),
(1040, 92, 'acf_field_added_2/path_0/name', 'Attorney Bio'),
(1041, 92, 'acf_field_added_2/path_0/type', 'field_group'),
(1042, 92, 'acf_field_added_2/path_1/name', 'Attorney Accolades'),
(1043, 92, 'acf_field_added_2/path_1/type', 'field'),
(1044, 92, 'acf_field_added_2/path_1/field_type', 'repeater'),
(1045, 92, 'acf_field_added_2/path_2/name', 'Accolade List'),
(1046, 92, 'acf_field_added_2/path_2/type', 'field'),
(1047, 92, 'acf_field_added_2/path_2/field_type', 'repeater'),
(1048, 92, 'acf_field_added_3/slug', 'attorney_accolades_0_accolade_list_2_single_bullet'),
(1049, 92, 'acf_field_added_3/key', 'field_5b1702a484750'),
(1050, 92, 'acf_field_added_3/label', 'Single Bullet'),
(1051, 92, 'acf_field_added_3/type', 'text'),
(1052, 92, 'acf_field_added_3/path_0/name', 'Attorney Bio'),
(1053, 92, 'acf_field_added_3/path_0/type', 'field_group'),
(1054, 92, 'acf_field_added_3/path_1/name', 'Attorney Accolades'),
(1055, 92, 'acf_field_added_3/path_1/type', 'field'),
(1056, 92, 'acf_field_added_3/path_1/field_type', 'repeater'),
(1057, 92, 'acf_field_added_3/path_2/name', 'Accolade List'),
(1058, 92, 'acf_field_added_3/path_2/type', 'field'),
(1059, 92, 'acf_field_added_3/path_2/field_type', 'repeater'),
(1060, 92, 'acf_field_added_4/slug', 'attorney_accolades_0_accolade_list_3_single_bullet'),
(1061, 92, 'acf_field_added_4/key', 'field_5b1702a484750'),
(1062, 92, 'acf_field_added_4/label', 'Single Bullet'),
(1063, 92, 'acf_field_added_4/type', 'text'),
(1064, 92, 'acf_field_added_4/path_0/name', 'Attorney Bio'),
(1065, 92, 'acf_field_added_4/path_0/type', 'field_group'),
(1066, 92, 'acf_field_added_4/path_1/name', 'Attorney Accolades'),
(1067, 92, 'acf_field_added_4/path_1/type', 'field'),
(1068, 92, 'acf_field_added_4/path_1/field_type', 'repeater'),
(1069, 92, 'acf_field_added_4/path_2/name', 'Accolade List'),
(1070, 92, 'acf_field_added_4/path_2/type', 'field'),
(1071, 92, 'acf_field_added_4/path_2/field_type', 'repeater'),
(1072, 92, 'acf_field_added_5/slug', 'attorney_accolades_0_accolade_list'),
(1073, 92, 'acf_field_added_5/key', 'field_5b1702918474f'),
(1074, 92, 'acf_field_added_5/label', 'Accolade List'),
(1075, 92, 'acf_field_added_5/type', 'repeater'),
(1076, 92, 'acf_field_added_5/path_0/name', 'Attorney Bio'),
(1077, 92, 'acf_field_added_5/path_0/type', 'field_group'),
(1078, 92, 'acf_field_added_5/path_1/name', 'Attorney Accolades'),
(1079, 92, 'acf_field_added_5/path_1/type', 'field'),
(1080, 92, 'acf_field_added_5/path_1/field_type', 'repeater'),
(1081, 92, 'acf_field_added_6/slug', 'attorney_accolades_1_accolade_header'),
(1082, 92, 'acf_field_added_6/key', 'field_5b1702868474e'),
(1083, 92, 'acf_field_added_6/label', 'Accolade Header'),
(1084, 92, 'acf_field_added_6/type', 'text'),
(1085, 92, 'acf_field_added_6/path_0/name', 'Attorney Bio'),
(1086, 92, 'acf_field_added_6/path_0/type', 'field_group'),
(1087, 92, 'acf_field_added_6/path_1/name', 'Attorney Accolades'),
(1088, 92, 'acf_field_added_6/path_1/type', 'field'),
(1089, 92, 'acf_field_added_6/path_1/field_type', 'repeater'),
(1090, 92, 'acf_field_added_7/slug', 'attorney_accolades_1_accolade_list_0_single_bullet'),
(1091, 92, 'acf_field_added_7/key', 'field_5b1702a484750'),
(1092, 92, 'acf_field_added_7/label', 'Single Bullet'),
(1093, 92, 'acf_field_added_7/type', 'text'),
(1094, 92, 'acf_field_added_7/path_0/name', 'Attorney Bio'),
(1095, 92, 'acf_field_added_7/path_0/type', 'field_group'),
(1096, 92, 'acf_field_added_7/path_1/name', 'Attorney Accolades'),
(1097, 92, 'acf_field_added_7/path_1/type', 'field'),
(1098, 92, 'acf_field_added_7/path_1/field_type', 'repeater'),
(1099, 92, 'acf_field_added_7/path_2/name', 'Accolade List'),
(1100, 92, 'acf_field_added_7/path_2/type', 'field') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1101, 92, 'acf_field_added_7/path_2/field_type', 'repeater'),
(1102, 92, 'acf_field_added_8/slug', 'attorney_accolades_1_accolade_list_1_single_bullet'),
(1103, 92, 'acf_field_added_8/key', 'field_5b1702a484750'),
(1104, 92, 'acf_field_added_8/label', 'Single Bullet'),
(1105, 92, 'acf_field_added_8/type', 'text'),
(1106, 92, 'acf_field_added_8/path_0/name', 'Attorney Bio'),
(1107, 92, 'acf_field_added_8/path_0/type', 'field_group'),
(1108, 92, 'acf_field_added_8/path_1/name', 'Attorney Accolades'),
(1109, 92, 'acf_field_added_8/path_1/type', 'field'),
(1110, 92, 'acf_field_added_8/path_1/field_type', 'repeater'),
(1111, 92, 'acf_field_added_8/path_2/name', 'Accolade List'),
(1112, 92, 'acf_field_added_8/path_2/type', 'field'),
(1113, 92, 'acf_field_added_8/path_2/field_type', 'repeater'),
(1114, 92, 'acf_field_added_9/slug', 'attorney_accolades_1_accolade_list_2_single_bullet'),
(1115, 92, 'acf_field_added_9/key', 'field_5b1702a484750'),
(1116, 92, 'acf_field_added_9/label', 'Single Bullet'),
(1117, 92, 'acf_field_added_9/type', 'text'),
(1118, 92, 'acf_field_added_9/path_0/name', 'Attorney Bio'),
(1119, 92, 'acf_field_added_9/path_0/type', 'field_group'),
(1120, 92, 'acf_field_added_9/path_1/name', 'Attorney Accolades'),
(1121, 92, 'acf_field_added_9/path_1/type', 'field'),
(1122, 92, 'acf_field_added_9/path_1/field_type', 'repeater'),
(1123, 92, 'acf_field_added_9/path_2/name', 'Accolade List'),
(1124, 92, 'acf_field_added_9/path_2/type', 'field'),
(1125, 92, 'acf_field_added_9/path_2/field_type', 'repeater'),
(1126, 92, 'acf_field_added_10/slug', 'attorney_accolades_1_accolade_list_3_single_bullet'),
(1127, 92, 'acf_field_added_10/key', 'field_5b1702a484750'),
(1128, 92, 'acf_field_added_10/label', 'Single Bullet'),
(1129, 92, 'acf_field_added_10/type', 'text'),
(1130, 92, 'acf_field_added_10/path_0/name', 'Attorney Bio'),
(1131, 92, 'acf_field_added_10/path_0/type', 'field_group'),
(1132, 92, 'acf_field_added_10/path_1/name', 'Attorney Accolades'),
(1133, 92, 'acf_field_added_10/path_1/type', 'field'),
(1134, 92, 'acf_field_added_10/path_1/field_type', 'repeater'),
(1135, 92, 'acf_field_added_10/path_2/name', 'Accolade List'),
(1136, 92, 'acf_field_added_10/path_2/type', 'field'),
(1137, 92, 'acf_field_added_10/path_2/field_type', 'repeater'),
(1138, 92, 'acf_field_added_11/slug', 'attorney_accolades_1_accolade_list'),
(1139, 92, 'acf_field_added_11/key', 'field_5b1702918474f'),
(1140, 92, 'acf_field_added_11/label', 'Accolade List'),
(1141, 92, 'acf_field_added_11/type', 'repeater'),
(1142, 92, 'acf_field_added_11/path_0/name', 'Attorney Bio'),
(1143, 92, 'acf_field_added_11/path_0/type', 'field_group'),
(1144, 92, 'acf_field_added_11/path_1/name', 'Attorney Accolades'),
(1145, 92, 'acf_field_added_11/path_1/type', 'field'),
(1146, 92, 'acf_field_added_11/path_1/field_type', 'repeater'),
(1147, 92, 'acf_field_added_12/slug', 'attorney_accolades'),
(1148, 92, 'acf_field_added_12/key', 'field_5b1702508474d'),
(1149, 92, 'acf_field_added_12/label', 'Attorney Accolades'),
(1150, 92, 'acf_field_added_12/type', 'repeater'),
(1151, 92, 'acf_field_added_12/path_0/name', 'Attorney Bio'),
(1152, 92, 'acf_field_added_12/path_0/type', 'field_group'),
(1153, 93, 'post_id', '19'),
(1154, 93, 'post_type', 'page'),
(1155, 93, 'post_title', 'Case Results'),
(1156, 93, '_message_key', 'post_updated'),
(1157, 93, '_user_id', '1'),
(1158, 93, '_user_login', '1p21.admin'),
(1159, 93, '_user_email', 'garrett@1pointinteractive.com'),
(1160, 93, '_server_remote_addr', '::'),
(1161, 93, '_server_http_referer', 'http://riddle-demo.com/wp-admin/edit.php?post_type=page') ;

#
# End of data contents of table `wp_simple_history_contexts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(23, 2, 0),
(24, 2, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(32, 2, 0),
(33, 2, 0),
(34, 2, 0),
(35, 2, 0),
(36, 2, 0),
(37, 2, 0),
(54, 3, 0),
(55, 3, 0),
(56, 3, 0),
(57, 3, 0),
(58, 3, 0),
(59, 3, 0),
(62, 4, 0),
(64, 4, 0),
(64, 5, 0),
(64, 6, 0),
(66, 6, 0),
(68, 6, 0),
(69, 6, 0),
(70, 5, 0),
(70, 6, 0),
(71, 2, 0),
(74, 3, 0),
(83, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 13),
(3, 3, 'nav_menu', '', 0, 7),
(4, 4, 'category', '', 0, 2),
(5, 5, 'category', '', 0, 2),
(6, 6, 'category', '', 0, 5) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'Practice Areas', 'practice-areas', 0),
(4, 'Cat 1', 'cat-1', 0),
(5, 'Cat 2', 'cat-2', 0),
(6, 'Cat 3', 'cat-3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', '1p21.admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"d9f436fbe7af8c57c0673f970e5b9b35a63771d05e840714e20534b7c7e4430c";a:4:{s:10:"expiration";i:1528338479;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36";s:5:"login";i:1528165679;}s:64:"3993940dafba738a7605ab939f41a7dc6bd53510f626b21a5155b5dbbcc1f8d3";a:4:{s:10:"expiration";i:1528406931;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36";s:5:"login";i:1528234131;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '45'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(20, 1, 'itsec_user_activity_last_seen', '1528237792'),
(21, 1, 'wp_yoast_notifications', 'a:3:{i:0;a:2:{s:7:"message";s:165:"Don\'t miss your crawl errors: <a href="http://riddle-demo.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:262:"You still have the default WordPress tagline, even an empty one is probably better. <a href="http://riddle-demo.com/wp-admin/customize.php?url=http%3A%2F%2Friddle-demo.com%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro">You can fix this in the customizer</a>.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:28:"wpseo-dismiss-tagline-notice";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:219:"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href="http://riddle-demo.com/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}}'),
(22, 1, 'gform_recent_forms', 'a:1:{i:0;s:1:"1";}'),
(23, 1, 'nav_menu_recently_edited', '2'),
(24, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(25, 1, 'wp_user-settings-time', '1528234546'),
(26, 1, '_itsec_has_logged_in', '1528234130'),
(27, 1, 'acf_user_settings', 'a:0:{}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$BiVAw1T3MdI7W1f4uPEzMbTPWOJ3x9/', '1p21-admin', 'garrett@1pointinteractive.com', '', '2018-05-24 15:18:28', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(1, '', 13, 0, 'internal') ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;


#
# Table structure of table `wp_yoast_seo_meta`
#

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_meta`
#
INSERT INTO `wp_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(4, 0, 0),
(13, 1, 0),
(19, 0, 0),
(43, 0, 0),
(46, 0, 0),
(48, 0, 0),
(50, 0, 0),
(52, 0, 0),
(60, 0, 0),
(62, 0, 0),
(64, 0, 0),
(66, 0, 0),
(68, 0, 0),
(69, 0, 0),
(70, 0, 0),
(81, 0, 0) ;

#
# End of data contents of table `wp_yoast_seo_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

